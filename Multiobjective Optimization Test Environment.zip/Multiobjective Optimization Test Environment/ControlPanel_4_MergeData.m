clear all; clc; % close all;
%
% This script combines data and solution variables from different folders
% in the '_Saved Results' folder. The merged results can then be analyzed
% using the 'ControlPanel_3_ApplyMetrics.m'
%
% Choose the folders in _Saved Results from which to merge the files. Then
% choose the file names to merge.


%% Choose the folders in '_Saved Results' from which the results are to be merged.
% write down the test folder names
desired_folders = strings();
desired_folders(1) = 'Data Set 1';
desired_folders(2) = 'Solution 1';






%% Begin merging files.
% start timing
clock_start = clock;

% write down the file names in the test set folders to be merged
desired_files = strings();
desired_files(1) = 'data.mat';
desired_files(2) = 'solutions.mat';

% include paths to main folders
% first determine operating system for folder naming
if     ispc

    slash = '\';

elseif ismac

    slash = '/';

end

% add paths to the following folders
addpath([pwd,slash,'Algorithms']);
addpath([pwd,slash,'Test Sets']);

% include all paths in the toolbox
addpath(genpath([pwd,slash,'Toolbox']));

% allow access to test sets to load the test problem objective functions
addpath([pwd,slash,'Test Sets',slash,'Wikipedia']);
addpath([pwd,slash,'Test Sets',slash,'DTLZ']);
addpath([pwd,slash,'Test Sets',slash,'Quadratics']);
addpath([pwd,slash,'Test Sets',slash,'Quadratics PSD']);
addpath([pwd,slash,'Test Sets',slash,'Sine Polynomials']);
addpath([pwd,slash,'Test Sets',slash,'User Defined']);

% move into the _Saved Results directory
old_folder = cd('_Saved Results');

% initialize merge variables
data = [];
sol  = [];

% get the list of items in this directory
dir_items = dir;

% remove the '.' and '..' directories
dir_items = dir_items(~ismember({dir_items.name},{'.', '..'}));

% look through the folders of saved results
for i = 1 : size(dir_items,1)

    % if a folder name matches the desired folder
    if any(strcmp(desired_folders,dir_items(i).name))  &&  dir_items(i).isdir 

        % check inside the saved results folder for the appropriate test sets
        files = dir(dir_items(i).name);
        files = files(~ismember({files.name},{'.', '..'}));

        % look through the saved files
        for k = 1 : size(files,1)

            % if this file name matches a desired file
            if any(strcmp(desired_files,files(k).name))

                % open the file
                % first get the file path
                file_path = [files(k).folder,slash,files(k).name];

                % get the parts of the file (e.g. ['C:\\...','file_name','.mat'])
                [path,name,ext] = fileparts(file_path);

                % check the file type
                if isequal(ext,'.mat')

                    % load the '.mat' file
                    mat_file = load([files(k).folder,slash,files(k).name]);      

                    % merge with existing data of same type
                    % NOTE: row headers must have matching algorithms
                    switch name

                        case 'data';       data = [data,mat_file.data];
                        case 'solutions';  sol  = [sol ,mat_file.sol ];

                    end
                end
            end
        end            
    end    
end

% create a new folder in the _Saved Results folder in which to store the tests
save_path = getSavePath('Merge',slash);
mkdir(save_path);

% save the merged data
save(fullfile(save_path,'data'),'data');
save(fullfile(save_path,'solutions'),'sol');

% move back to the original directory
cd(old_folder);

% save a summary of the details
file_name = [save_path,slash,'details of merge.txt'];
fileID = fopen(file_name,'a');
fprintf(fileID,"Details of Merge - " + datestr(datetime('now')) + "\n\n");

fprintf(fileID,pad("Folders Merged: ",20) + strjoin(desired_folders,', ') + "\n");
fprintf(fileID,pad("Files Merged: ",20) + strjoin(desired_files,', ') + "\n\n");
    
% finish timing
clock_end = clock;
[days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);

fprintf(fileID,"Merge completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs);

fprintf(fileID,"\n");
fclose(fileID);

% print summary message
fprintf("Merge completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs)
