function [days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end)
    
    % reckon the seconds
    if clock_end(6) - clock_start(6) < 0

        clock_end(5) = clock_end(5) - 1;
        clock_end(6) = clock_end(6) + 60;
        
    end
    
    secs = clock_end(6) - clock_start(6);
    
    % reckon the minutes
    if clock_end(5) - clock_start(5) < 0

        clock_end(4) = clock_end(4) - 1;
        clock_end(5) = clock_end(5) + 60;
        
    end
    
    mins = clock_end(5) - clock_start(5);
    
    % reckon the hours
    if clock_end(4) - clock_start(4) < 0

        clock_end(3) = clock_end(3) - 1;
        clock_end(4) = clock_end(4) + 24;
        
    end
    
    hrs = clock_end(4) - clock_start(4);
    
    % it is assumed that the test will not take more than 1 month
    days = clock_end(3) - clock_start(3);
    
end
