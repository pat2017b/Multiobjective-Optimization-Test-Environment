function save_path = getSavePath(new_path,slash)

    % create a folder name and test to see if it exists in the _Saved Results folder
    % first, try the folder 'Test 1'
    sub_path  = [new_path,' ','1'];
    save_path = [pwd,slash,sub_path];
    
    % then, check if the file exists; if it does, increment to 'Test k'
    k = 1;
    while exist(save_path,'dir')
        
        k = k + 1;
        
        sub_path  = [new_path,' ',num2str(k)];
        save_path = [pwd,slash,sub_path];
        
    end
end
