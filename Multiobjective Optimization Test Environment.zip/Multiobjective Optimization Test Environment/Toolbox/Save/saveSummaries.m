function saveSummaries(data,rel_mtcs,summary,path,slash)

    % get number of algorithms and problems
    [num_algs,num_probs,~] = size(rel_mtcs);  % rel_mtcs already has failures filtered
    
    % save a summary of the results problem by problem in CSV format
    file_name = [path,slash,'summary of problems.txt'];
    fileID = fopen(file_name,'a');
        
    % create title bar with proper padding
    % write in CSV format (Comma Separated Values)
    seg_lgth    = 25;
    str_prob    = pad("Problems,",seg_lgth);
    str_alg     = pad("Algorithms,",seg_lgth);
    str_evals   = pad("Max Evals,",seg_lgth);
    str_used    = pad("Evals Used,",seg_lgth);
    str_time    = pad("Rel Time,",seg_lgth);
    str_hv      = pad("Rel HV,",seg_lgth);
    str_ctrb    = pad("Rel Ctrb,",seg_lgth);
    str_eps_ind = pad("Rel Eps-Ind,",seg_lgth);
    fprintf(fileID,str_prob + str_alg + str_evals + str_used + str_time + str_hv + str_ctrb + str_eps_ind + "\n\n");

    % fill the file with a summary of the data
    for prob = 1 : num_probs

        % add the algorithms and their results
        for alg = 1 : num_algs

            % write statistics from the data variable
            fprintf(fileID,pad(data{alg,prob}.prob_name  + ",",seg_lgth));
            fprintf(fileID,pad(data{alg,prob}.alg_name   + ",",seg_lgth));
            fprintf(fileID,pad(data{alg,prob}.max_evals  + ",",seg_lgth));
            fprintf(fileID,pad(data{alg,prob}.evals_used + ",",seg_lgth));

            for mtc = 1 : size(rel_mtcs,3)

                % write this algorithm's metric result on this problem
                fprintf(fileID,pad(num2str(rel_mtcs(alg,prob,mtc)) + ",",seg_lgth));

            end

            fprintf(fileID,"\n");

        end
    end
    
    fclose(fileID);
    
    % save summary of analysis
    file_name = [path,slash,'summary of analysis.txt'];
    fileID = fopen(file_name,'a');
    
    for cell = 1 : size(summary,2)

        for line = 1 : size(summary{cell},2)

            % write this line from this paragraph
            fprintf(fileID,summary{cell}(line) + "\n");

        end

        % add a line of space between analysis metrics
        fprintf(fileID,"\n");

    end
    
    fclose(fileID);
        
end
