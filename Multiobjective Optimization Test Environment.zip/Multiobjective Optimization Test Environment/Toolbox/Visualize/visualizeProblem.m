function figure = visualizeProblem(data)

    % unpack variable names
    prob_name  = data.prob_name;
    prob_ss    = data.search_space;
    dim_domain = data.dim_domain;
    num_obj    = data.num_obj;
    alg_name   = data.alg_name;
    visited_X  = data.visited_X;
    visited_F  = data.visited_F;
    
    for i = 1 : size(data.f_,2)
        
        f{i} = data.f_{i};
    
    end
    
    % initialize figure
    figure = initFig(alg_name,prob_name);
    
    % check if domain or objective range is visualizable
    if data.dim_domain > 3    &&    data.num_obj > 3
        
        disp("Dimension and number of objectives are too high to visualize.")
        return;
        
    end

     % filter the caches into different categories for visualization
    [inf_X,nInf_X,nInf_F,POpt_X,POpt_F] = filterForVisualization(visited_X,visited_F);

    % build visual elements
    % first determine the display configuration
    num_funcs  = size(f,2);
    
    % follow this pattern for handling the number of subplots
    
    %   1   1   1 3     1 3     1 3     1 3     1 3 7   1 3 7   1 3 7
    %       2   2       2 4     2 4     2 4     2 4     2 4 8   2 4 8
    %                           5       5 6     5 6     5 6     5 6 9
    
    % 1  3  7   1  3  7     1  3  7     1  3  7  13     1  3  7  13
    % 2  4  8   2  4  8     2  4  8     2  4  8         2  4  8  14
    % 5  6  9   5  6  9     5  6  9     5  6  9         5  6  9  15
    % 10        10 11       10 11 12    10 11 12        10 11 12 16
    
    % 1  3  7  13   1  3  7  13     1  3  7  13     1  3  7  13
    % 2  4  8  14   2  4  8  14     2  4  8  14     2  4  8  14
    % 5  6  9  15   5  6  9  15     5  6  9  15     5  6  9  15
    % 10 11 12 16   10 11 12 16     10 11 12 16     10 11 12 16
    % 17            17 18           17 18 19        17 18 19 20
    
    % 1  3  7  13  21
    % 2  4  8  14
    % 5  6  9  15       ...
    % 10 11 12 16
    % 17 18 19 20
    
    % the first columns shows a pattern of a_i = (i-1)^2 + 1 
    % determine the number of rows needed for the functions
    num_rows = ceil(sqrt(num_funcs));
    
    % then determine the number of columns needed for the functions using the rows
    num_cols_f = ceil(num_funcs/num_rows);
    
    % determine the number of rows needed for functions and output data
    if num_rows < 4
        
        % a column for domain and a column for range space
        num_cols = num_cols_f + 2;  
        
        % indices for output of results (used later)
        ind_dom_1 = num_cols - 1;
        ind_dom_2 = 2*num_cols - 1;
        ind_rge_1 = num_cols;
        ind_rge_2 = 2*num_cols; 

    else  % num_rows_f >= 4
        
        % a single column for domain and range space
        num_cols = num_cols_f + 1;  

        % indices for output of results (used later)
        ind_dom_1 = num_cols;
        ind_dom_2 = 2*num_cols;
        ind_rge_1 = 3*num_cols;
        ind_rge_2 = 4*num_cols; 
    
    end
    
    % create objective function subplots
    funcs_plotted = 0;
    for i = 1 : num_cols_f
        
        for j = 1 : num_rows
    
            if funcs_plotted < num_funcs
            
                func = funcs_plotted + 1;
                
                plot_ind  = i + (j-1)*num_cols;
                plot_axes{func} = subplot(num_rows,num_cols,plot_ind);
                plot_axes{func} = plotFunction(plot_axes{func},f{func},num2str(func),prob_ss,dim_domain);

                funcs_plotted = funcs_plotted + 1;
    
            end
        end
    end
    
    % plot output of algorithm
    dom      = subplot(num_rows,num_cols,ind_dom_1);
    dom      = plotDomainOrRange(dom,'Domain',inf_X,nInf_X,POpt_X,dim_domain);
    dom_zoom = subplot(num_rows,num_cols,ind_dom_2);
    dom_zoom = plotZoomedDomainOrRange(dom_zoom,'Domain',POpt_X,dim_domain);
    rge      = subplot(num_rows,num_cols,ind_rge_1);
    rge      = plotDomainOrRange(rge,'Objective Space',[],nInf_F,POpt_F,num_obj);
    rge_zoom = subplot(num_rows,num_cols,ind_rge_2);
    rge_zoom = plotZoomedDomainOrRange(rge_zoom,'Objective Space',POpt_F,num_obj);

end


function sub_plot = plotFunction(sub_plot,f,num,ss,dim)

    bounds  = [min(ss(:,1),[],1),max(ss(:,2),[],1)];
    spacing = (bounds(2)-bounds(1))/100;
        
    if     dim == 1
        
        x = bounds(1):spacing:bounds(2);
        y = arrayfun(@(x) f(x),x);
        plot(x,y)
        
        xlabel('x-axis')
        ylabel('f(x)')
    
    elseif dim == 2
        
        [X,Y] = meshgrid(bounds(1):spacing:bounds(2));
        Z     = arrayfun(@(x1,x2) f([x1;x2]),X,Y);
        surf(X,Y,Z)
        
        xlabel('x_1-axis')
        ylabel('x_2-axis')
        zlabel('f(x)')
    
    end
    
    title("Objective Function " + num);
    
end


function sub_plot = plotDomainOrRange(sub_plot,tag,inf_pts,nInf_pts,ParO_pts,dim)
    
    scatterPts(inf_pts ,dim,tag,10,[  0,255,  0]/256);     % infinite points in GREEN
    scatterPts(nInf_pts,dim,tag,10,[127,127,127]/256);     % normal   points in GREY
    scatterPts(ParO_pts,dim,tag,10,[255,  0,  0]/256);     % Pareto   points in RED
    
    title("Plot of the " + tag);
    
end


function sub_plot = plotZoomedDomainOrRange(sub_plot,tag,ParO_pts,dim)

    scatterPts(ParO_pts,dim,tag,10,[255,  0,  0]/256);     % Pareto   points in RED
    
    title("Plot of the Optimal " + tag);
    
end


function scatterPts(pts,dim,tag,dot_sz,col)
    
    if isempty(pts)
        
        return;
        
    elseif dim == 1

        scatter(pts(1,:),zeros(1,size(pts,2)),dot_sz,col,'filled');
        hold on;
        
        if     strcmp(tag,'Domain')
        
            xlabel('x-axis');
            ylabel('');
            
        end
    
    elseif dim == 2

        scatter(pts(1,:),pts(2,:),dot_sz,col,'filled');
        hold on;
        
        if     strcmp(tag,'Domain')
        
            xlabel('x_1-axis');
            ylabel('x_2-axis');
            
        elseif strcmp(tag,'Objective Space')
           
            xlabel('f_1-axis');
            ylabel('f_2-axis');
            
        end
    
    elseif dim == 3
    
        scatter3(pts(1,:),pts(2,:),pts(3,:),dot_sz,col,'filled');
        hold on;
        
        if     strcmp(tag,'Domain')
        
            xlabel('x_1-axis');
            ylabel('x_2-axis');
            zlabel('x_3-axis');
            
        elseif strcmp(tag,'Objective Space')
           
            xlabel('f_1-axis');
            ylabel('f_2-axis');
            zlabel('f_3-axis');
            
        end
    end
end


function fig = initFig(alg_name,prob_name)

    fig = figure('NumberTitle', 'Off');
    ttl = "Algorithm " + alg_name + " on problem " + prob_name;
    set(fig,'Name',ttl);        % set fig title bar
    
    % centre figure based on screen size
    res  = get(0,'Screensize');
    lgth = 900;
    wdth = 600;
    left = (res(3) - lgth)/2;
    top  = (res(4) - wdth)/2;
    dim  = [left, top, lgth, wdth];
    set(fig, 'Position', dim);
    
end
