function figure = visualizeSolution(data_set,sol_set)
    
    % unpack variable names
    prob_name  = data_set{1}.prob_name;
    sol_X      = sol_set{1};
    sol_F      = sol_set{2};
    dim_domain = size(sol_X,1);
    num_obj    = size(sol_F,1);
    
    % initialize the figure
    figure = initFig(prob_name);
    
    % check if domain or objective range is visualizable
    if size(sol_set{1,1},1) > 3    &&    size(sol_set{2,1},1) > 3
        
        disp("Dimension and number of objectives are too high to visualize.")
        return;
        
    end
    
    % save seed of rng and randomly generate colours
    pre_seed = rng;
    new_seed = 13;  % test different colour sets (13 is ok)
    rng(new_seed);
    
    if     dim_domain == 1      % 1-D visual

        % plot Pareto optimal points in the domain
        subplot(2,2,1)
        title("Plot of the Combined Optimal Domain");
        scatter(sol_X(1,:),zeros(1,size(sol_X,2)),10,[255,0,0]/256,'filled')    % colour RED
        xlabel('x-axis')
        
        % and below plot each algorithm's contribution
        subplot(2,2,3)
        title("Plot of Algorithm Contributions");
        for alg = 1 :  size(data_set,1)
           
            if isempty(data_set{alg,1}.POpt_X)
                
                continue;
                
            end
            
            scatter(data_set{alg,1}.POpt_X,zeros(1,size(data_set{alg,1}.POpt_X,2)),10,rand(1,3))        % random colour
            hold on;
            
        end        
        xlabel('x-axis')
        
    elseif dim_domain == 2      % 2-D visual

        % plot Pareto optimal points in the domain
        subplot(2,2,1)
        title("Plot of the Combined Optimal Domain");
        scatter(sol_X(1,:),sol_X(2,:),10,[255,0,0]/256,'filled')
        xlabel('x_1-axis')
        ylabel('x_2-axis')
        
        % and below plot each algorithm's contribution
        subplot(2,2,3)
        title("Plot of Algorithm Contributions");
        for alg = 1 :  size(data_set,1)
           
            if isempty(data_set{alg,1}.POpt_X)
                
                continue;
                
            end
           
            scatter(data_set{alg,1}.POpt_X(1,:),data_set{alg,1}.POpt_X(2,:),10,rand(1,3))
            hold on;
            
        end        
        xlabel('x_1-axis')
        ylabel('x_2-axis')
        
    elseif dim_domain == 3      % 3-D visual

        % plot Pareto optimal points in the domain
        subplot(2,2,1)
        title("Plot of the Combined Optimal Domain");
        scatter3(sol_X(1,:),sol_X(2,:),sol_X(3,:),10,[255,0,0]/256,'filled')
        xlabel('x_1-axis')
        ylabel('x_2-axis')
        zlabel('x_3-axis')
        
        % and below plot each algorithm's contribution
        subplot(2,2,3)
        title("Plot of Algorithm Contributions");
        for alg = 1 :  size(data_set,1)
           
            if isempty(data_set{alg,1}.POpt_X)
                
                continue;
                
            end
           
            scatter3(data_set{alg,1}.POpt_X(1,:),data_set{alg,1}.POpt_X(2,:),data_set{alg,1}.POpt_X(3,:),10,rand(1,3))
            hold on;
            
        end        
        xlabel('x_1-axis')
        ylabel('x_2-axis')
        zlabel('x_3-axis')
    
    end
        
    % reuse the seed to reuse the old colours on the next plot
    rng(new_seed);
    
    % visualize the solution set
    
    if     num_obj == 2         % 2-D visual
        
        % plot Pareto optimal points in the objective space
        subplot(2,2,2)
        title("Plot of Combined Objective Space");
        scatter(sol_F(1,:),sol_F(2,:),10,[255,0,0]/256,'filled');
        xlabel('f_1-axis')
        ylabel('f_2-axis')
        
        % and below plot each algorithm's contribution
        subplot(2,2,4)
        title("Plot of Objective Space Contributions");
        for alg = 1 :  size(data_set,1)
           
            if isempty(data_set{alg,1}.POpt_X)
                
                continue;
                
            end
           
            scatter(data_set{alg,1}.POpt_F(1,:),data_set{alg,1}.POpt_F(2,:),10,rand(1,3))
            hold on;
            
        end        
        xlabel('f_1-axis')
        ylabel('f_2-axis')

    elseif num_obj == 3         % 3-D visual
        
        % plot Pareto optimal points in the objective space
        subplot(2,2,2)
        title("Plot of Combined Objective Space");
        scatter3(sol_F(1,:),sol_F(2,:),sol_F(3,:),10,[255,0,0]/256,'filled');
        xlabel('f_1-axis')
        ylabel('f_2-axis')
        zlabel('f_3-axis')
        
        % and below plot each algorithm's contribution
        subplot(2,2,4)
        title("Plot of Objective Space Contributions");
        for alg = 1 :  size(data_set,1)
           
            if isempty(data_set{alg,1}.POpt_X)
                
                continue;
                
            end
           
            scatter3(data_set{alg,1}.POpt_F(1,:),data_set{alg,1}.POpt_F(2,:),data_set{alg,1}.POpt_F(3,:),10,rand(1,3))
            hold on;
            
        end        
        xlabel('f_1-axis')
        ylabel('f_2-axis')
        zlabel('f_3-axis')

    end
        
    % return seed to previous state
    rng(pre_seed);
    
end


function fig = initFig(prob_name)

    fig = figure('NumberTitle', 'Off');
    set(fig, 'Name', "Combined Solution to Problem " + prob_name);       % set fig title bar
    
    % centre figure based on screen size
    res  = get(0,'Screensize');
    lgth = 600;
    wdth = 600;
    left = (res(3) - lgth)/2;
    top  = (res(4) - wdth)/2;
    dim  = [left, top, lgth, wdth];
    set(fig, 'Position', dim);
    
end
