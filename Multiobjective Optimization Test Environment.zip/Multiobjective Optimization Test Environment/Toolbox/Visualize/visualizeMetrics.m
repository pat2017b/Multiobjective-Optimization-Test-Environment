function fig = visualizeMetrics(alg_names,metric_names,rel_mtcs)
    
    % CURRENT ASSUMPTION: time is at rel_mtcs(:,:,1)
    % remove the time metric
    rel_mtcs = rel_mtcs(:,:,2:end);

    % get numbers of algorithms, problems, and metrics
    [num_algs,num_probs,num_mtcs] = size(rel_mtcs);

    % prepare the figure
    fig = figure('NumberTitle', 'Off');
    ttl = "Metrics Applied to Test Results";
    set(fig,'Name',ttl);        % set fig title bar
    
    % determine the display configuration
    num_rows = floor(num_mtcs/4) + 1;
    num_cols = ceil(num_mtcs/num_rows);
    
    for mtc = 1 : num_mtcs

        plot_axes{mtc} = subplot(num_rows,num_cols,mtc);
            
    end

    % centre figure based on screen size and number of subplots
    res  = get(0,'Screensize');
    lgth = 400*num_cols;
    wdth = 400*num_rows;
    left = (res(3) - lgth)/2;
    up   = (res(4) - wdth)/2;
    dim  = [left, up, lgth, wdth];
    set(fig, 'Position', dim);
    
    % loop through and display metrics
    for mtc = 1 : num_mtcs
        
        % set subplot
        axes(plot_axes{mtc});           
        hold on;
        
        % make list of colours, symbols
        col  = ['k','k','r','b','m','c','y'];
        linS = {'-',':','-','-','-','--','-.'};
        symb = ['s','d','p','v','o','*','x'];
        
        for alg = 1 : num_algs
            
            F = rel_mtcs(alg,:,mtc);
            
            % get the algorithm's accuracy by percentage point
            X = 0 : 0.01 : 1;
            Y = zeros(size(X));
            
            for i = 1 : size(X,2)
                
                acc  = X(i);
                Y(i) = sum(bsxfun( @le, acc, F))/num_probs; 
                
            end
            
            % add stairs with no symbols
            h = stairs(X,Y,'LineWidth',2,'Color',col(alg),'LineStyle',linS{alg});
            set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
            hold on;
            
            % add ending symbol
            plot(X(end),Y(end),'LineWidth',2,'Color',col(alg),'Marker',symb(alg),...
                'MarkerFaceColor',col(alg),'DisplayName',alg_names{alg},'LineStyle',linS{alg})
            hold on;
            
        end
        
        % resize graph if accuracy is uniformly 100 for so many tests
        % first, get Y data from graph
        graph = findobj(gca);
        
        % get the stairs data (which lies with the axes and lines)
        for i = 3 : 2 : size(graph,1)
            
            % put all Y data into one big array of rows of Y
            Y_data((i-1)/2,:) = graph(i).YData;
            
        end
        
        % then find first accuracy X in [0,1] for which Y is not equal to 0.95
        for i = 1 : size(Y_data,2)
            
            if ~(sum(bsxfun(@le,0.95*ones(size(Y_data,1),1),Y_data(:,i))) == size(Y_data,1))
                
                break;
                
            end
        end
        
        %correct for the cases where i == 100
        if i > 95
            
            i = 95;
            
        end
        
        % resize plot: set new x-axis limits: [x_min,x_max]
        xlim([floor(i/10)/10 1]); 
              
        % add labels
        xlabel('Accuracy');
        ylabel('% of Problems Passed')
        legend('Location','southwest');
        title(metric_names{mtc});
        hold off;
        
    end
end
