function [app_set_X,app_set_F] = filterParetoPoints(X,F)

    list_dom = zeros(1,size(F,2));  % container for list of dominated vectors
    
    for i = 1 : size(F,2)
        
        vec_dom  = sum(bsxfun(@lt,F(:,i),F)) == size(F,1);      % get vectors dominated by F_i(x)
        list_dom = list_dom | vec_dom;                      	% add vectors to list of dominated vectors
        
    end
    
    app_set_X = X(:,~list_dom);     % keep the undominated vectors
    app_set_F = F(:,~list_dom);
    
end