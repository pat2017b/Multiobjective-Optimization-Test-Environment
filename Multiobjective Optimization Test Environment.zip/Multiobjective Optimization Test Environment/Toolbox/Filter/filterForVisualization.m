function [inf_X, nInf_X, nInf_F, POpt_X, POpt_F] = filterCaches(X,F)

    % Initialize return values.
    inf_X  = [];
    nInf_X = [];
    nInf_F = [];
    POpt_X = [];
    POpt_F = [];
    
    i_dom = zeros(1,size(F,2));     % helper variable

    % Loop through multiobjective function values F_i.
    for i = 1 : size(F,2)

        % If F_i has no infinite values...
        if isinf(F(:,i)) == zeros(size(F,1))

            % then loop through F_j.
            for j = 1 : size(F,2)
                
                % If F_j has been shown to be dominated...
                if i_dom(j)

                    % skip it.
                    continue;

                % If F_j dominates F_i...
                elseif dom(F(:,j),F(:,i))

                    % add x_i, F_i to the non-infinite set.
                    nInf_X = [nInf_X,X(:,i)];
                    nInf_F = [nInf_F,F(:,i)];

                    i_dom(i) = 1;   % Record dominated F_i to skip it in subsequent j loops.
                    break;          % Go to next i.

                end

                % If the end has been reached...
                if j == size(F,2)

                    % add x_i to the Pareto optimal set.
                    POpt_X = [POpt_X,X(:,i)];
                    POpt_F = [POpt_F,F(:,i)];

                end 
            end
        
        else    % If there is an infinite value in F_i...

            inf_X = [inf_X,X(:,i)];     % save the x_i in the inf variable;
            i_dom(i) = 1;               % record F_i to skip it in subsequent j loops;
            continue;                   % and continue to the next i.

        end
    end
end


function u_dom_v = dom(u,v)

    % Initlialize the return variable to true (i.e. u dominates v).
    u_dom_v = true;

    if  isequal(u,v)

        u_dom_v = false;    % Allow only strict domination.

    else        % If u and v are not equal...

        for i = 1 : size(u,1)

            % Check if some u_i is worse than v_i.
            if	u(i) > v(i)

                u_dom_v = false;
                break;

            end
        end
    end
end
