clear all; clc; % close all;
%
% This script applies metrics on a data set and a solution set and returns
% relative metric values, an accuracy profile, a CSV text summary of the 
% data problem-by-problem, and a summary file of cumulative metric results.
%
% Select a folder name from '_Saved Results' containing the desired files 
% and choose the files (default: 'data.mat' and 'solutions.mat') to be
% measured. Then choose the metrics with which to measure the files' data.


%% Choose the folder in '_Saved Results' from which the results are to be measured.
% write down the results folder's name
desired_folder = 'Data Set 1';


%% Choose from the list of available metrics.
% 'Hypervolume'
% 'Contribution'
% 'Epsilon Indicator'
metric_names = {'Hypervolume';'Contribution';'Epsilon Indicator'};


%% Choose whether to save the results in '_Saved Results' folder.
save_ = 1;      % 0 = don't save; 1 = do save


%% Choose whether to receive command window messages updating the progress.
echo = 1;       % 0 = don't print; 1 = do print





%% Begin applying metrics to files.
% start timing
clock_start = clock;

% write down the file names in the test set folder
desired_files = strings();
desired_files(1) = 'data.mat';
desired_files(2) = 'solutions.mat';

% include paths to main folders
% first determine operating system for folder naming
if     ispc

    slash = '\';

elseif ismac

    slash = '/';

end

% allow access to load the test problem objective functions
addpath([pwd,slash,'Test Sets',slash,'Wikipedia']);
addpath([pwd,slash,'Test Sets',slash,'DTLZ']);
addpath([pwd,slash,'Test Sets',slash,'Quadratics']);
addpath([pwd,slash,'Test Sets',slash,'Quadratics PSD']);
addpath([pwd,slash,'Test Sets',slash,'Sine Polynomials']);
addpath([pwd,slash,'Test Sets',slash,'User Defined']);

% include paths to metric folders
addpath([pwd,slash,'Metrics']);

% include all paths in the toolbox
addpath(genpath([pwd,slash,'Toolbox']));

% move into the _Saved Results directory
old_folder = cd('_Saved Results');

% initialize variables
data = [];
sol  = [];

% get the list of items in this directory
dir_items = dir;

% remove the '.' and '..' directories
dir_items = dir_items(~ismember({dir_items.name},{'.', '..'}));

% look through the folders of saved results
for i = 1 : size(dir_items,1)

    % if a folder name matches the desired folder
    if any(strcmp(desired_folder,dir_items(i).name))  &&  dir_items(i).isdir 

        % check inside the saved results folder for the appropriate test sets
        files = dir(dir_items(i).name);
        files = files(~ismember({files.name},{'.', '..'}));

        % look through the saved files
        for k = 1 : size(files,1)

            % if this file name matches a desired file
            if any(strcmp(desired_files,files(k).name))

                % open the file
                % first get the file path
                file_path = [files(k).folder,slash,files(k).name];

                % get the parts of the file (e.g. ['C:\\...','file_name','.mat'])
                [path,name,ext] = fileparts(file_path);

                % check the file type
                if     isequal(ext,'.mat')

                    % load the '.mat' file
                    mat_file = load(file_path);      

                    % store the data and solutions variables locally
                    switch name

                        case 'data';            data = mat_file.data;
                        case 'solutions';     	sol  = mat_file.sol;

                    end
                end
            end
        end            
    end    
end

% move back to the original directory
cd(old_folder);

% get algorithm names
alg_names = cell(size(data,1),1);

for i = 1 : size(data,1)
    
    alg_names{i,1} = data{i,1}.alg_name;
    
end

% collect the measurement data
[rel_mtcs,summary] = applyMetrics(data,sol,alg_names,metric_names,echo);

% visualize metrics
figure = visualizeMetrics(alg_names,metric_names,rel_mtcs);

% finish timing
clock_end = clock;
[days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);

% print summary of measurement
if echo
    
    % print summary text to the command window cell by cell
    for cell = 1 : size(summary,2)

        for line = 1 : size(summary{cell},2)

            disp(summary{cell}(line));

        end

        % add a line of space between analysis metrics
        fprintf("\n");

    end
end


%% Save
if save_
    
    save(fullfile([path,slash,'relative metrics.mat']),'rel_mtcs');
    savefig([path,slash,'accuracy profiles.fig']);
    saveSummaries(data,rel_mtcs,summary,path,slash);

    % save a summary of the details
    file_name = [path,slash,'details of metrics.txt'];
    fileID = fopen(file_name,'a');
    fprintf(fileID,"Details of Metrics - " + datestr(datetime('now')) + "\n\n");
    
    fprintf(fileID,pad("Folders Measured: ",20) + desired_folder + "\n");
    fprintf(fileID,pad("Metrics Used: ",20) + strjoin(metric_names,', ') + "\n\n");

    fprintf(fileID,"Measurement completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs);
    
    fprintf(fileID,"\n");
    fclose(fileID);
    
end

% print summary message
if echo
    
    fprintf("Measurement completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs)
    
end
