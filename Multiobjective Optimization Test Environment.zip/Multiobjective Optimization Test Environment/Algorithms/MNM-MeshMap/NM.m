function data = NM(params)

    % initialize the data return variable
    data.F          = params.F;
    data.weights    = params.weights;
    data.Y          = params.Y;
    data.F_Y        = params.F_Y;
    data.evals_used = 0;
    data.visited_X  = [];
    data.visited_F  = [];
    
    % shorten parameter names
    max_evals = params.max_evals;
    stopCond  = params.stopCond;
    del_e     = params.del_e;       % expansion
    del_oc    = params.del_oc;      % outside contraction
    del_ic    = params.del_ic;      % inside contraction
    gam       = params.gam;         % shrink
    
    % begin main NM iteration
    while data.evals_used < max_evals    &&    ~stopCond(data.F_Y,data.weights)
        
        % reorder the simplex
        [Y,f_Y,data] = reorderSimplex(data);

        % set some variables for ease of reading
        y_n    = Y(:,end);
        f_y0   = f_Y(:,1);
        f_yn_1 = f_Y(:,end-1);
        f_yn   = f_Y(:,end);

        x_c = centroid(Y(:,1:end-1));           % find the centroid of Y\{y_n}

        x_r = x_c + (x_c - y_n);                % find the reflection point
        [f_r,F_r,data] = poll(x_r,data);        % poll the reflection point

        if  f_y0 < f_r    &&    f_r < f_yn_1    % if f(y_0) < f(x_r) < f(y_(n-1))

            data.Y  (:,end) = x_r;              % replace y_n    with x_r
            data.F_Y(:,end) = F_r;              % and     F(y_n) with F(x_r)

        elseif f_r < f_y0                       % if f(x_r) < f(y_0)

            x_e = x_c + del_e*(x_c - y_n);      % find the expansion point
            [f_e,F_e,data] = poll(x_e,data);	% poll the expansion point

            if	f_e < f_r                       % if f(x_e) < f(x_r)

                data.Y  (:,end) = x_e;          % replace y_n    with x_e
                data.F_Y(:,end) = F_e;          % and     F(y_n) with F(x_e)

            else                                % if f(x_r) <= f(x_e)

                data.Y  (:,end) = x_r;          % replace y_n    with x_r
                data.F_Y(:,end) = F_r;          % and     F(y_n) with F(x_r)

            end

        elseif f_r < f_yn                       % if f(y_(n-1)) < f(x_r) < f(y_n)

            x_oc = x_c + del_oc*(x_c - y_n);   	% find the outside contraction point
            [f_oc,F_oc,data] = poll(x_oc,data); % poll the outside contraction point

            if	f_oc < f_r                      % if f(x_oc) < f(x_r)

                data.Y  (:,end) = x_oc;         % replace y_n    with x_oc
                data.F_Y(:,end) = F_oc;         % and     F(y_n) with F(x_oc)

            else                                % if f(x_r) <= f(x_oc)

                data.Y  (:,end) = x_r;          % replace y_n    with x_r
                data.F_Y(:,end) = F_r;          % and     F(y_n) with F(x_r)

            end

        else                                   	% else f(y_n) < f(x_r)

            x_ic = x_c + del_ic*(x_c - y_n);  	% find the inside contraction point
            [f_ic,F_ic,data] = poll(x_ic,data);	% poll the inside contraction point

            if	f_ic < f_yn                     % if f(x_ic) < f(y_n)

                data.Y  (:,end) = x_ic;         % replace y_n    with x_ic
                data.F_Y(:,end) = F_ic;         % and     F(y_n) with F(x_ic)

            else

                data = shrink(gam,data);

            end
        end
    end    
end


function [Y,f_Y,data] = reorderSimplex(data)

    f_Y = zeros(1,size(data.F_Y,2));
    
    for i = 1 : size(data.F_Y,2)                
        
        f_Y(i) = dot(data.weights,data.F_Y(:,i));   % evaluate f_x = w dot F(x)
        
    end
    
    i       = 1;
    swapped = false;
    while i < size(f_Y,2)

        if  f_Y(i) > f_Y(i+1)

            temp            = f_Y(i);           % swap columns in each matrix
            f_Y(i)          = f_Y(i+1);
            f_Y(i+1)        = temp;
            
            temp            = data.Y(:,i);
            data.Y(:,i)     = data.Y(:,i+1);
            data.Y(:,i+1)   = temp;
            
            temp            = data.F_Y(:,i);
            data.F_Y(:,i)   = data.F_Y(:,i+1);
            data.F_Y(:,i+1) = temp;
            
            swapped  = true;                    % and note that a swap was made
                                                
        end

        i = i+1;                                % increment array index

        if  i == size(f_Y,2) && swapped         % if end reached with a swap

            i       = 1;                        % return to the beginning
            swapped = false;

        end
    end
    
    Y = data.Y;
    
end


function data = shrink(gam,data)

	for i = 2 : size(data.Y,2)
        
        y_0 = data.Y(:,1);
        y_i = data.Y(:,i);

        data.Y(:,i)   = y_0 - gam*(y_i - y_0);      % set  new y_i
        [~,F_x,data]  = poll(data.Y(:,i),data);     % poll new y_i
        data.F_Y(:,i) = F_x;                        % set  new F(y_i)

    end
end


function [f_x,F_x,data] = poll(x,data)
 
    F_x             = data.F(x);
    data.evals_used = data.evals_used + 1;
    data.visited_X  = [data.visited_X,x  ];
    data.visited_F  = [data.visited_F,F_x];
    
    f_x = dot(data.weights,F_x);      % evaluate f_x = w dot F(x)

end


function x_c = centroid(X)

    x_sum = zeros(size(X,1),1);

    for i = 1 : size(X,2)

        x_sum = x_sum + X(:,i);     % add all the vectors together

    end

    x_c = x_sum./size(X,2);         % divide by the number of vectors

end
