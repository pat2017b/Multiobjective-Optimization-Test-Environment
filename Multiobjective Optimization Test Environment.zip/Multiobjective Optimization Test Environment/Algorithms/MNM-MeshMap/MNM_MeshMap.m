function [visited_X,visited_F] = MNM_MeshMap(params)

    F            = params.F;
    search_space = params.search_space;
    dim_domain   = params.dim_domain;
    num_obj      = params.num_obj;
    max_evals    = params.max_evals;
    mesh_order   = params.mesh_order;
    init_prime   = params.init_prime;
    prime_max    = params.prime_max;
    init_epsilon = params.init_epsilon;
    evals_used   = 0;
    visited_X    = [];
    visited_F    = [];
    
    % begin algorithm
    prime_num = init_prime;     % starting prime number for mesh map
    epsilon_0 = init_epsilon;	% starting accuracy for convergence
    while evals_used < max_evals
        
        min_quality  = 0.5;     % minimum acceptable approximate normalized volume of the simplex
        Y = makeSimplex(search_space,min_quality);

        % evaluate starting simplex Y
        for i = 1 : size(Y,2)

            F_Y(:,i)   = F(Y(:,i));                 
            visited_X  = [visited_X,Y(:,i)];
            visited_F  = [visited_F,F_Y(:,i)];
            evals_used = evals_used + 1;

        end
        
        % construct the mesh map
        mesh_params.num_rings  = nthprime(prime_num);
        mesh_params.num_obj    = num_obj;
        mesh_params.mesh_order = mesh_order;
        mesh_map = makeMeshMap(mesh_params);
            
        % begin looping through the current mesh_map
     	i = 1;                  % index for mesh-map array
        NM_visited_X = [];      % this NM iteration's visited points
        NM_visited_F = [];
        
        epsilon = epsilon_0;	% reset accuracy
        
        while evals_used < max_evals    &&    i <= size(mesh_map,2)

            % set parameters for Nelder-Mead algorithm with given total preorder
          	params_NM.F         = F;
           	params_NM.weights   = mesh_map(:,i);
          	params_NM.Y         = Y;
           	params_NM.F_Y       = F_Y;
            params_NM.max_evals = max_evals - evals_used;
            params_NM.stopCond  = @(X,weights) stopCond(X,weights,epsilon);
            params_NM.del_e     =    2;     % expansion
            params_NM.del_oc    =  1/2;     % outside contraction
            params_NM.del_ic    = -1/2;     % inside contraction
            params_NM.gam       =  1/2;     % shrink

            % run Nelder-Mead algorithm
            data_NM = NM(params_NM);                    

            % transfer data from Nelder-Mead results
            Y            = data_NM.Y;
            F_Y          = data_NM.F_Y;
            NM_visited_X = [NM_visited_X,data_NM.visited_X];
            NM_visited_F = [NM_visited_F,data_NM.visited_F];
            evals_used   = evals_used + data_NM.evals_used;

            % increment mesh_map array index
            i = i+1;
            
            % adjust accuracy
            if isempty(data_NM.visited_F)
                
                epsilon = epsilon/2;        % magnify 
                
            end
        end
        
        % save data from NM through the mesh
        visited_X = [visited_X,NM_visited_X];
        visited_F = [visited_F,NM_visited_F];

        % adjust mesh map density
        if prime_num > prime_max
            
            % the mesh is getting too dense; restart
            prime_num = init_prime;                  
            
        else
            
            % otherwise make it denser
            prime_num = prime_num + 1;      
            
        end
    end
end
