function Y = makeSimplex(search_space,min_quality)

    % get the dimension of the search space
    dim = size(search_space,1);
    
    % construct a simplex with a reasonable shape
    simplex_accepted = false;
    while ~simplex_accepted
        
        a = search_space(:,1);
        b = search_space(:,2);
        Y = a + rand(dim,dim + 1).*(b-a);   % randomly generate some values for Y
    
        
        %% Mathematical simplex test
        % construct the L matrix to test for a non-zero determinant
%         for i = 2 : size(Y,2)
% 
%             L(:,i-1) = Y(:,i) - Y(:,1);     % L = [y_1 - y_0 ... y_n - y_0]
% 
%         end
        
        % if the determinant of L is zero
%         if det(L) == 0
%             
%             % go to the next iteration to try a new simplex
%             continue;
%             
%         end

        % else simplex accepted
        

        %% Simplex shape test
        % test the shape of the simplex by comparing the smallest edge to the largest:
        % first, find the maximum and minimum edges of the simplex
        min_diam = inf;
        max_diam = 0;
        
        for i = 1 : size(Y,2)
            
            for j = i+1 : size(Y,2)
                
                edge_diam = norm(Y(:,i)-Y(:,j));
                
                if edge_diam > max_diam
                    
                    max_diam = edge_diam;
                    
                end
                
                if edge_diam < min_diam
                    
                    min_diam = edge_diam;
                    
                end
            end
        end

        % then, get the ratio, a number between 0 and 1
         ratio = min_diam / max_diam;
        
        % accept the simplex when the ratio is above a certain quality
        if ratio > min_quality  % input parameter
            
            simplex_accepted = true;
            
        end
    end    
end
