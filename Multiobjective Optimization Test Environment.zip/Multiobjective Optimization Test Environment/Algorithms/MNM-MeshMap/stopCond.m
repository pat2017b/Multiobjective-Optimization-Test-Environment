function within = stopCond(F_Y,weights,epsilon)
    
    % initialize return variable
    within = true;   
    
    % reconstruct the weighted evaluation of the simplex
    for i = 1 : size(F_Y,2)
        
        f_Y(i) = dot(F_Y(:,i),weights);
        
    end

    % loop through all pairs of vectors of f(Y)
    for i = 1 : size(f_Y,2)

        for j = i + 1 : size(f_Y,2)               
            
            if  abs(f_Y(i)-f_Y(j)) > epsilon        % if |f(y^i)-f(y^j)| > epsilon
                
                within = false;                     % then the simplex's vectors are not within the tolerance
                return;                             % exit the function
                
            end
        end
    end
end