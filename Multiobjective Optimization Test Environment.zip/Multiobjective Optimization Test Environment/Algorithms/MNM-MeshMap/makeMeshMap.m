function mesh_map = makeMeshMap(params)

    % simplify variable names
    num_rings  = params.num_rings;
    num_obj    = params.num_obj;
    mesh_order = params.mesh_order;

  	% begin at the Origin, the all 1 vectors
    mesh_map = ones(num_obj,1);
    
    % construct each ring and add it to the mesh
    for ring = 1 : num_rings
        
        density   = ring;
        radius    = ring/num_rings;
        mesh_ring = makeMeshRing(density,radius,num_obj);
        mesh_map  = [mesh_map,mesh_ring];
        
    end
    
    % modify ordering of the mesh points
    switch mesh_order
        
        case 'In to Out'
            
            % order left unchanged
        
        case 'Random'
            
            % randomize order of mesh map points
            rand_order = randperm(size(mesh_map,2));
            mesh_map = mesh_map(:,rand_order);
            
        case 'Out to In'
            
            % reverse order of 'In to Out'
            reverse_order = size(mesh_map,2) : -1 : 1;
            mesh_map = mesh_map(:,reverse_order);
    
    end
end


function mesh_ring = makeMeshRing(density,radius,num_obj)
    
    % represent each function's local minimum, that is, the corners of the hypersphere model
    Id = eye(num_obj);              
    
    % initialize the outer ring variable
    ring = [];
    
    % for each pair of vectors of mesh_ring = I
    for i = 1 : num_obj
        
        for j = i+1 : num_obj       
            
            % add this many equally spaced points between them
            for k = 0 : density     
                
                ring = [ring,(k/density)*Id(:,j) + ((density-k)/density)*Id(:,i)];
                
            end
        end
    end
    
    % set the Origin at the centre of the ring
    O = ones(num_obj,1);
    
    % initialize the return variables
    mesh_ring = [];
    
    % then shrink the ring in to the desired radius
    for i = 1 : size(ring,2)        
        
        mesh_ring = [mesh_ring,(1-radius)*O + radius*ring(:,i)];
        
    end
end
