clear all; clc; close all;

%% CONTROL PANEL

% choose density (number of points on each ring segment), radius from all 1 vect on mesh map and number of objective functions
density_array = [0,1,2,3,4,5,6,7,8];
radius_array  = [0,1/8,2/8,3/8,4/8,5/8,6/8,7/8,1];
num_obj = 3;

% grey scale constants to shade rings differently
grey_scale = flip(radius_array);

% choose whether to see the final mesh (0) or a point-by-point construction
% of the mesh (1)
pt_by_pt = 0;
   

%% build and display the mesh ring

for j = 1 : size(density_array,2)
    
    density = density_array(j);
    radius  = radius_array(j);
    grey    = grey_scale(j);
        
    % deal with the origin separately
    if j == 1
        
        mesh_ring = ones(3,1)/sqrt(3);
        
    else

        mesh_ring = makeMeshRing(density,radius,num_obj);
        
    end

    for i = 1 : size(mesh_ring,2)

        mesh_ring(:,i) = mesh_ring(:,i)./norm(mesh_ring(:,i));      % normalize ring's points for visualization

    end

    displayMesh(mesh_ring,num_obj,pt_by_pt,density,radius,grey);
    hold on;

end


%% visualize the mesh
function displayMesh(mesh,num_obj,pt_by_pt,density,radius,grey)

    BLACK  = [0,0,0];
    dot_sz = 80;
    if pt_by_pt     % if point-by-point look at the mesh
        if num_obj == 2
            circle();
            
        elseif num_obj == 3
            sphere();
            view([1,1,1]);
            
        end
        hold on;
        pbaspect([1,1,1]);
            
        % save to file
        str = ['MeshRingD',num2str(density),'R',num2str(radius),'N',num2str(num_obj),'-0.jpg'];
        %if i == size(mesh,2) saveas(gcf,str); end
        %saveas(gcf,str);
        
        pause(2);
        for i = 1 : size(mesh,2)
            if    num_obj == 2
                scatter(mesh(1,i),mesh(2,i),dot_sz,BLACK,'filled');
                hold on;
            
                % save to file
                str = ['MeshRingD',num2str(density),'R',num2str(radius),'N',num2str(num_obj),'-',num2str(i),'.jpg'];
                %saveas(gcf,str);
                
            elseif num_obj == 3
                
                scatter3(mesh(1,i),mesh(2,i),mesh(3,i),dot_sz,BLACK,'filled');
                hold on;
                
                % save to file
                str = ['MeshRingD',num2str(density),'R',num2str(radius),'N',num2str(num_obj),'-',num2str(i),'.jpg'];
                %if i == size(mesh,2) saveas(gcf,str); end
                %saveas(gcf,str);

            else
                disp("Cannot display mesh; dimension = " + num_obj);
            end
            
            pause(0.1);
        end

    else            % look at full mesh
        if     num_obj == 2
            circle();
            hold on;
            pbaspect([1,1,1]);
            scatter(mesh(1,:),mesh(2,:),dot_sz,BLACK,'filled');
                
            % save to file
            str = ['MeshRingD',num2str(density),'R',num2str(radius),'N',num2str(num_obj),'-',num2str(i),'.jpg'];
            saveas(gcf,str);
            
        elseif num_obj == 3
            sphere();
            hold on;
            pbaspect([1,1,1]);
            view([1,1,1]);
            
            % modify for grey scale
            colour = [1,1,1]*grey;
            scatter3(mesh(1,:),mesh(2,:),mesh(3,:),dot_sz,colour,'filled');
                
            % save to file
            str = ['MeshRingD',num2str(density),'R',num2str(radius),'N',num2str(num_obj),'.jpg'];
            saveas(gcf,str);
            
        else
            disp("Cannot display mesh; dimension = " + num_obj);
        end
    end
end


%% graph the unit circle
function h = circle()
    th = 0:pi/50:2*pi;
    xunit = cos(th);
    yunit = sin(th);
    h = plot(xunit, yunit);
    hold on;
end