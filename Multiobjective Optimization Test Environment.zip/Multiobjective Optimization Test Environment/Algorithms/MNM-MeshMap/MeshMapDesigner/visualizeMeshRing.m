clear all; clc; close all;

%% CONTROL PANEL

% choose density (number of points on each ring segment), radius from all 1 vect on mesh map and number of objective functions
density = 10;
radius  = 0.5;
num_obj = 3;

% choose whether to see the final mesh (0) or a point-by-point construction
% of the mesh (1)
pt_by_pt = 0;
   

%% build and display the mesh

mesh_ring = makeMeshRing(density,radius,num_obj);

for i = 1 : size(mesh_ring,2)
    
    mesh_ring(:,i) = mesh_ring(:,i)./norm(mesh_ring(:,i));      % normalize ring's points for visualization
    
end

displayMesh(mesh_ring,num_obj,pt_by_pt);


%% visualize the mesh
function displayMesh(mesh,num_obj,pt_by_pt)

    BLACK  = [0,0,0];
    dot_sz = 20;
    if pt_by_pt     % if point-by-point look at the mesh
        if num_obj == 2
            circle();
        elseif num_obj == 3
            sphere();
            view([1,1,1]);
        end
        hold on;
        pbaspect([1,1,1]);
        pause(2);
        for i = 1 : size(mesh,2)
            if    num_obj == 2
                scatter(mesh(1,i),mesh(2,i),dot_sz,BLACK,'filled');
                hold on;
            elseif num_obj == 3
                scatter3(mesh(1,i),mesh(2,i),mesh(3,i),dot_sz,BLACK,'filled');
                hold on;
            else
                disp("Cannot display mesh; dimension = " + num_obj);
            end
            pause(0.5);
        end

    else            % look at full mesh
        if     num_obj == 2
            circle();
            hold on;
            pbaspect([1,1,1]);
            scatter(mesh(1,:),mesh(2,:),dot_sz,BLACK,'filled');
        elseif num_obj == 3
            sphere();
            hold on;
            pbaspect([1,1,1]);
            view([1,1,1]);
            scatter3(mesh(1,:),mesh(2,:),mesh(3,:),dot_sz,BLACK,'filled');
        else
            disp("Cannot display mesh; dimension = " + num_obj);
        end
    end
end


%% graph the unit circle
function h = circle()
    th = 0:pi/50:2*pi;
    xunit = cos(th);
    yunit = sin(th);
    h = plot(xunit, yunit);
    hold on;
end