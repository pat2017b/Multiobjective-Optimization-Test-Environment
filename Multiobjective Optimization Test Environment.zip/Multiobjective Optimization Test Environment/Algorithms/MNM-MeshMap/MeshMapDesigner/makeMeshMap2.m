function mesh_map = makeMeshMap2()
    
    % make an usual mesh-map
    num_obj = 3;

    mesh_map = ones(num_obj,1);  	% begin at the all 1 vectors
    
    mesh_ring = makeMeshRing(20,1,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
    
    mesh_ring = makeMeshRing(5,0.9,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
    
    mesh_ring = makeMeshRing(7,0.75,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
    
    mesh_ring = makeMeshRing(10,0.63,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
    
    mesh_ring = makeMeshRing(2,0.3,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
    
    mesh_ring = makeMeshRing(1,0.1,num_obj);
    mesh_map  = [mesh_map,mesh_ring];
   
end