clear all; clc; close all;

%% CONTROL PANEL

% choose number of rings on mesh map and number of objective functions
num_rings = 3;
num_obj   = 3;

% choose whether to see the final mesh (0) or a point-by-point construction
% of the mesh (1)
pt_by_pt = 0;


%% build and display the mesh

mesh_map = makeMeshMap(num_rings,num_obj);

for i = 1 : size(mesh_map,2)
    
    mesh_map(:,i) = mesh_map(:,i)./norm(mesh_map(:,i));     % normalize points for visualization
    
end

displayMesh(mesh_map,num_obj,pt_by_pt,num_rings);


%% visualize the mesh
function displayMesh(mesh_map,num_obj,pt_by_pt,num_rings)

    BLACK  = [0,0,0];
    dot_sz = 30;
    if pt_by_pt     % if point-by-point look at the mesh
        if num_obj == 2
            circle();
        elseif num_obj == 3
            sphere();
            view([1,1,1]);
        end
        hold on;
        pbaspect([1,1,1]);
        pause(2);
        for i = 1 : size(mesh_map,2)
            if    num_obj == 2
                scatter(mesh_map(1,i),mesh_map(2,i),dot_sz,BLACK,'filled');
                hold on;
            elseif num_obj == 3
                scatter3(mesh_map(1,i),mesh_map(2,i),mesh_map(3,i),dot_sz,BLACK,'filled');
                hold on;
            else
                disp("Cannot display mesh; dimension = " + num_obj);
            end
            pause(0.5);
        end

    else            % look at full mesh
        if     num_obj == 2
            circle();
            hold on;
            pbaspect([1,1,1]);
            scatter(mesh_map(1,:),mesh_map(2,:),dot_sz,BLACK,'filled');
        elseif num_obj == 3
            sphere();
            hold on;
            pbaspect([1,1,1]);
            view([1,1,1]);
            scatter3(mesh_map(1,:),mesh_map(2,:),mesh_map(3,:),dot_sz,BLACK,'filled');
            
                
            % save to file
            str = ['MeshMapNR',num2str(num_rings),'.jpg'];
            saveas(gcf,str);
            
        else
            disp("Cannot display mesh; dimension = " + num_obj);
        end
    end
end


%% graph the unit circle
function h = circle()
    th = 0:pi/50:2*pi;
    xunit = cos(th);
    yunit = sin(th);
    h = plot(xunit, yunit);
    hold on;
end