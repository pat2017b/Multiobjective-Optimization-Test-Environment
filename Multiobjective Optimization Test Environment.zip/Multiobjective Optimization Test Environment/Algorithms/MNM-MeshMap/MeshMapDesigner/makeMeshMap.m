function mesh_map = makeMeshMap(num_rings,num_obj)

    mesh_map = ones(num_obj,1);  	% begin at the all 1 vectors
    
    for ring = 1 : num_rings
        
        density   = ring;
        radius    = ring/num_rings;
        mesh_ring = makeMeshRing(density,radius,num_obj);
        mesh_map  = [mesh_map,mesh_ring];
        
    end
end