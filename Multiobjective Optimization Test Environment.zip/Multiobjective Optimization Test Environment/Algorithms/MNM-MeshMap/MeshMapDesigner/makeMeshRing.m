function mesh_ring = makeMeshRing(density,radius,num_obj)
    
    Id = eye(num_obj);              % represents each function's local minimum
    
    ring = [];
    
    for i = 1 : num_obj
        
        for j = i+1 : num_obj       % for each pair of vectors of mesh_ring = I
            
            for k = 0 : density   % add this many equally spaced points between them
                
                ring = [ring,(k/density)*Id(:,j) + ((density-k)/density)*Id(:,i)];
                
            end
        end
    end
    
    O = ones(num_obj,1);            % Origin at the centre of the ring
    
    mesh_ring = [];
    
    for i = 1 : size(ring,2)        % then contract the ring in to the desired radius
        
        mesh_ring = [mesh_ring,(1-radius)*O + radius*ring(:,i)];
        
    end
end