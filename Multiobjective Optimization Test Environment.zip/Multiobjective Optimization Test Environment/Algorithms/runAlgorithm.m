function data = runAlgorithm(alg_name,problem,crash_test)

    % start timing
    tic;        
    
    % include paths to algorithm folders:
    % first, determine operating system for folder naming
    if     ispc

        slash = '\';

    elseif ismac

        slash = '/';

    end
    
    % include paths to algorithm folders
    addpath([pwd,slash,'Algorithms',slash,'Random Search']);
    addpath([pwd,slash,'Algorithms',slash,'Grid Search']);
    addpath([pwd,slash,'Algorithms',slash,'MOPSO']);
    addpath([pwd,slash,'Algorithms',slash,'NSGA-II']);
    addpath([pwd,slash,'Algorithms',slash,'MNM-MeshMap']);
        
    % prepare variables for data
    visited_X = [];
    visited_F = [];
    crashed   = 0;      % 0 = did not crash; 1 = did crash    
    
    % set parameters
    switch alg_name

        case 'Random Search'    % Random Search in a Hyper-rectangle

            % set algorithm parameters
            params = problem;

        case 'Grid Search'      % Grid Search in a Hyper-rectangle

            % set algorithm parameters
            params = problem;

        case 'MOPSO'            % Multi-Objective Particle Swarm Optimization

            % compute an appropriate repository size
            rep_sz = (floor(problem.max_evals/100));

            % set algorithm parameters
            MultiObj.fun     = problem.Ft;
            MultiObj.nVar    = problem.dim_domain;
            MultiObj.var_min = transpose(problem.search_space(:,1));
            MultiObj.var_max = transpose(problem.search_space(:,2));

            params        = problem;
            params.Np     = rep_sz; % Population size
            params.Nr     = rep_sz; % Repository size
            params.maxgen = 99;     % Maximum number of generations
            params.W      = 0.4;    % Inertia weight
            params.C1     = 2;      % Individual confidence factor
            params.C2     = 2;      % Swarm confidence factor
            params.ngrid  = 20;     % Number of grids in each dimension
            params.maxvel = 5;      % Maxmium vel in percentage
            params.u_mut  = 0.5;    % Uniform mutation percentage

        case 'NSGA-II'          % Non-Dominated Sorted Genetic Algorithm

            % compute max population size
            pop_sz = (floor(problem.max_evals/100));

            % algorithm parameters
            params          = problem;
            params.pop_size = pop_sz;
            params.gen_max  = 99;

        case 'MNM-MeshMap'        % Multiobjective Nelder-Mead with in to out mesh-map

            % algorithm parameters
            params              = problem;
            params.init_prime   = 1;
            params.prime_max    = 5;
            params.init_epsilon = 0.1;
            params.mesh_order   = 'In to Out';  % also 'Random' and 'Out to In'

    end    
    
    % run the algorithm:
    % if this is a crash test, allow the algorithm to crash
    if crash_test
        
        switch alg_name
            
            case 'Random Search';       [visited_X,visited_F] = RandomSearch(params);
            case 'Grid Search';         [visited_X,visited_F] = GridSearch(params);
            case 'MOPSO';               [visited_X,visited_F] = MOPSO(params,MultiObj);
            case 'NSGA-II';             [visited_X,visited_F] = NSGA2(params);
            case 'MNM-MeshMap';         [visited_X,visited_F] = MNM_MeshMap(params);
                
        end 
    
    % if this is not a crash test, catch the algorithm's error and record the crash
    else
        
        try

            switch alg_name

                case 'Random Search';       [visited_X,visited_F] = RandomSearch(params);
                case 'Grid Search';         [visited_X,visited_F] = GridSearch(params);
                case 'MOPSO';               [visited_X,visited_F] = MOPSO(params,MultiObj);
                case 'NSGA-II';             [visited_X,visited_F] = NSGA2(params);
                case 'MNM-MeshMap';         [visited_X,visited_F] = MNM_MeshMap(params);

            end        

        catch ERROR

            % error not handled
            
            % note that it crashed
            crashed = 1;

        end
    end
    
    % prepare the data variable for output
    data            = params;     % give the new data variable all the parameters of this problem
    data.alg_name   = alg_name;   % and include these...
    data.visited_X  = visited_X;
    data.visited_F  = visited_F;
    data.evals_used = size(visited_X,2);
    data.crashed    = crashed;
    data.hasNaN_X   = sum(sum(isnan(visited_X))) > 0;
    data.hasNaN_F   = sum(sum(isnan(visited_X))) > 0;

    % get Pareto optimal sets
    [data.POpt_X,data.POpt_F] = filterParetoPoints(data.visited_X,data.visited_F);
        
    % finish timing
    data.time = toc;

end
