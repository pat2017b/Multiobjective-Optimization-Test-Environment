function [visited_X,visited_F] = RandomSearch(params)
% Input:
% params.F                  % multiobjective vector function
%       .max_evals          % maximum allowed number of function evalutaions
%       .search_space       % dimensions of hyper-rectangular search space
%
% Output:
% visited_X                 % set of visited points
% visited_F                 % function evaluations of corresponding visited points

    % initialize return variables
    visited_X = [];   % visited domain points
    visited_F = [];   % function evaluations of corresponding domain points
    
    % unpack variable names
    F     = params.F;
    evals = params.max_evals;
    HR    = params.search_space;	% nx2 array of the hyper-rectangular search space bounds
    
    % determine the dimension of the search space
    dim = size(HR,1);
    
    % create a set of random points in the search space
    set = HR(:,1) + (HR(:,2) - HR(:,1)).*rand(dim,evals);
    
    % search through the set of random points
    for p = 1 : size(set,2)
        
        % get the point for this iteration and evaluate it
        x   = set(:,p);
        F_x = F(x);
        
        % store the data
        visited_X = [visited_X,x];
        visited_F = [visited_F,F_x];
        
    end
end
