function [visited_X,visited_F] = GridSearch(params)
% Input:
% params.F                  % multiobjective vector function
%       .max_evals          % maximum allowed number of function evalutaions
%       .search_space       % dimensions of hyper-rectangular search space
%
% Output:
% visited_X                 % set of visited points
% visited_F                 % function evaluations of corresponding visited points

    % initialize return variables
    visited_X = [];   % visited domain points
    visited_F = [];   % function evaluations of corresponding domain points
    
    % unpack variable name
    F = params.F;
    
    % construct a grid of points in the search space
    grid = constructGrid(params);
    
    % search through the grid
    for p = 1 : size(grid,2)
        
        % get the grid point for this iteration
        x   = grid(:,p);
        F_x = F(x);
        
        % store the data
        visited_X = [visited_X,x];
        visited_F = [visited_F,F_x];
        
    end
end


function grid = constructGrid(params)

    % unpack variables names
    max_evals  = params.max_evals;
    HR         = params.search_space;    % hyper-rectangle of the search space

    % determine the dimension of the search space
    dim = size(HR,1);
    
    % determine the maximum number of partitions that can fit inside max_evals
    % first, attempt the simplest partition (i.e. corners of hyper-rectangle)
    % note that one partition has two points, two partitions have three points, etc.
    num_parts = 1;
    
    while (num_parts+1)^dim <= max_evals
        
        % 1 partition = 2^dim points fits inside the search space
        % increment the number of partitions and try the next one
        num_parts = num_parts + 1;      

    end
    
    % adjust for the case when num_parts = 1 (which causes problems below)
    num_parts = max(2,num_parts);                
    
    % get the measurements delta that will partition each dimension, 
    delta = zeros(dim,1);
    
    for i = 1 : dim
        
        delta(i) = (HR(i,2)-HR(i,1)) / (num_parts-1);
        
    end
    
    % create a blank grid to be populated
    grid = zeros(dim,min(num_parts^dim,dim));
    
    % loop through all possible points
    iter = 1;
    while iter <= num_parts^dim    &&    iter <= max_evals
        
        % prepare the next grid point's vector
        x = [];
        
        % begin at the last component of the vector x and work backward
        comp_of_x = dim; 
                
        % recursively construct the vector x given its order in the grid
        % example:
        % 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2
        % 0 0 0 1 1 1 2 2 2 0 0 0 1 1 1 2 2 2 0 0 0 1 1 1 2 2 2
        % 0 1 2 0 1 2 0 1 2 0 1 2 0 1 2 0 1 2 0 1 2 0 1 2 0 1 2
        x = getVector(x,iter,num_parts,delta,HR,dim,comp_of_x);
        
        % add the point to the grid
        grid(:,iter) = x;
        
        % increment the iteration counter
        iter = iter + 1;
    
    end
end


function x = getVector(x,i,num_parts,delta,HR,dim,comp_of_x)

    % get the index of the component
    index = dim - comp_of_x + 1;
    
    % get the grid level
    grid_lvl = (num_parts)^(comp_of_x-1);

    % x_i = lower_boundary_i + spacing_i * modulated i^th point in the enumeration
    x(index) = HR(index,1) + delta(index)*mod(floor((i-1)/grid_lvl),(num_parts));
    
    % continue filling in the coordinates of x
    if comp_of_x > 1  
        
        comp_of_x = comp_of_x - 1;
        x = getVector(x,i,num_parts,delta,HR,dim,comp_of_x);
        
    end
end
