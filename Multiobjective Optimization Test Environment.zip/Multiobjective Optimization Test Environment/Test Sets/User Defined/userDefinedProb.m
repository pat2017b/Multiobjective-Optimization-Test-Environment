% Test specific problem

function problem = userDefinedProb(prob_num)
    %% Set parameters
    
    switch prob_num
        
        case 1      % paraboloid and cubic
            
            % set parameters
            prob_name    = "Common Functions";
            search_space = [-5,5;-5,5];
            dim_domain   = 2;
            num_obj      = 2;
            max_evals    = 1000;
            
            % write corresponding functions
            f_{1} = @(x) sum(x.^2) + infBar(x,search_space);
            f_{2} = @(x) sum(x.^3) + infBar(x,search_space);
    
        case 2      % three parabolas
            
            % set parameters
            prob_name    = "Three Parabolas";
            search_space = [-5,5];
            dim_domain   = 1;
            num_obj      = 3;
            max_evals    = 1000;
            
            % write corresponding functions
            f_{1} = @(x) (x(1)-2)^2 + infBar(x,search_space);
            f_{2} = @(x) x(1)^2     + infBar(x,search_space);
            f_{3} = @(x) (x(1)+2)^2 + infBar(x,search_space);
    
        case 3      % four paraboloids
            
            % set parameters
            prob_name    = "Four Paraboloids";
            search_space = [-5,5;-5,5];
            dim_domain   = 2;
            num_obj      = 4;
            max_evals    = 1000;
            
            % write corresponding functions
            f_{1} = @(x) (x(1)-1)^2 + (x(2)-1)^2 + infBar(x,search_space);
            f_{2} = @(x) (x(1)-1)^2 + (x(2)+1)^2 + infBar(x,search_space);
            f_{3} = @(x) (x(1)+1)^2 + (x(2)-1)^2 + infBar(x,search_space);
            f_{4} = @(x) (x(1)+1)^2 + (x(2)+1)^2 + infBar(x,search_space);

        case 4      % n paraboloids
            
            % set parameters
            prob_name    = "n Paraboloids";
            search_space = [-5,5;-5,5];
            dim_domain   = 2;
            num_obj      = 4;
            max_evals    = 1000;
            
            % place the paraboloids evenly along the circumference of a circle
            p1 = @(i,num_obj) cos(i*2*pi/num_obj);
            p2 = @(i,num_obj) sin(i*2*pi/num_obj);
            
            for i = 1 : num_obj

                v = [p1(i-1,num_obj),p2(i-1,num_obj)];
                f_{i}  = @(x) (x(1)-v(1))^2 + (x(2)-v(2))^2 + infBar(x,search_space);

            end
    end
    
    
    %% Create the problem using the parameters above.
    % construct the multiobjective vector function
    F = @(x) [];
    for i = 1 : num_obj
        
        F = @(x) [F(x);f_{i}(x)];
        
    end
    
    % construct the transpose of the function (for MOPSO and NSGA-II)
    Ft = @(x) [];
    for i = 1 : num_obj
        
        Ft = @(x) [Ft(x),f_{i}(transpose(x))];
        
    end
    
    % construct the constraint equations to calculate error (for NSGA-II)
    C = @(x) 0;	% no constraints in this problem set
    
    % prepare the problem
    problem.test_set_name = "User Defined Problems";
    problem.prob_name     = prob_name;
    problem.f_            = f_;
    problem.F             = F;
    problem.Ft            = Ft;
    problem.C             = C;
    problem.search_space  = search_space;
    problem.dim_domain    = dim_domain;
    problem.num_obj       = num_obj;
    problem.max_evals     = max_evals;
    
end


% indicator function used to build an infinite barrier outside of the 
% search space
function c = infBar(x,search_space)

    % check if x is outside the search space
    for i = 1 : size(search_space,1)
        
        if x(i) < search_space(i,1)    ||    x(i) > search_space(i,2)
            
            c = inf;
            return;
            
        end
    end
    
    % else if x is inside the search space
    c = 0;
    
end
