% select a problem from the specified test set and parameters
% install test sets here and select parameters

function problem = selectProblem(params)

    % include paths to test set folders
    % first determine operating system for folder naming
    if     ispc

        slash = '\';

    elseif ismac

        slash = '/';

    end
    
    % include paths to test set folders
    addpath([pwd,slash,'Test Sets',slash,'Wikipedia']);
    addpath([pwd,slash,'Test Sets',slash,'DTLZ']);
    addpath([pwd,slash,'Test Sets',slash,'Quadratics']);
    addpath([pwd,slash,'Test Sets',slash,'Quadratics PSD']);
    addpath([pwd,slash,'Test Sets',slash,'Sine Polynomials']);
    addpath([pwd,slash,'Test Sets',slash,'User Defined']);

    % simplify variable names
    test_set = params.test_set;
    prob_num = params.prob_num;
    
    % check if the 'params' variable has 'DTLZ_num' for DTLZ problems
    if any(strcmp(fieldnames(params),'DTLZ_num'))
        
        DTLZ_num = params.DTLZ_num;
        
    end
    
    % check if the 'params' variable has 'dim_rge' for generated problems
    if any(strcmp(fieldnames(params),'dim_rge'))
    
        dim_rge  = params.dim_rge;
        obj_rge  = params.obj_rge;
        ss_bnd   = params.ss_bnd;
    
    end

    % select the problem within the appropriate test set
    switch test_set
        
        case 'Wikipedia'           % prob_num <= 19 for this one
            
            problem = selectWikiProb(prob_num);
            
        case 'DTLZ'
            
            % run the problem from the specified DTLZ problem subset
            if 0 < DTLZ_num < 8
                
                problem  = selectDTLZProb(DTLZ_num,prob_num);
                
            end
            
            % if DTLZ == 0, the modulus of the problem number determines
            % the DTLZ number (from 1 to 7) and the quotient of the problem
            % number determines the problem number
            if DTLZ_num == 0

                % get the DTLZ number
                set_num = mod(prob_num,7);     

                % however the modulus of test set 7 returns 0, so correct this
                if ~set_num

                    set_num = 7;

                end

                prob_num = ceil(prob_num/7);
                problem  = selectDTLZProb(set_num,prob_num);
                
            end
            
        case 'Quadratics'
            
            problem = selectQuadProb(prob_num,dim_rge,obj_rge,ss_bnd);
            
        case 'Quadratics PSD'       % Positive Semi-Definite
            
            problem = selectQuadPSDProb(prob_num,dim_rge,obj_rge,ss_bnd);
            
        case 'Sine Polynomials'
            
            problem = selectSinPolyProb(prob_num,dim_rge,obj_rge,ss_bnd);
            
        case 'User Defined'
            
            problem = userDefinedProb(prob_num);    % see Test Sets -> User Defined -> userDefinedProb.m
            
    end
end
