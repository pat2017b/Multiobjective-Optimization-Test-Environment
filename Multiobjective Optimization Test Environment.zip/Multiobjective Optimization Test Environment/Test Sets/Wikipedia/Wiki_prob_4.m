% Function 4:  Test function 4
% Wikipedia:   Test functions for optimization
% Address:     https://en.wikipedia.org/wiki/Test_functions_for_optimization
% Section:     Test functions for multiobjective optimization

function problem = Wiki_prob_4()
    
    % set multiobjective function and constraints (objective functions found below)
    f_{1} = @(x) f(1,x);
    f_{2} = @(x) f(2,x);
    F     = @(x) [f(1,x);f(2,x)];
    Ft    = @(x) [transpose(f(1,x)),transpose(f(2,x))];
    C     = @(x) [max(0,x(1)/6 + x(2) - 6.5),max(0,0.5*x(1) + x(2) - 7.5),max(0,5*x(1) + x(2) - 30)];
    
    % prepare the problem
    problem.prob_name    = 'Wiki-4-Test-4';
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = [-7,4;-7,4];
    problem.dim_domain   = 2;
    problem.num_obj      = 2;
    problem.max_evals    = problem.dim_domain*(problem.num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(m,x)

    if m == 1   % objective function f_1
        
        f_x = x(1)^2 - x(2) + infBar(x);                                     
        
    else        % objective function f_2
        
        f_x = -0.5*x(1) - x(2) - 1 + infBar(x);
        
    end
end


% infinite barrier function
function c = infBar(x)

    % check if x is outside the search space
    if     x(1) < -7 || x(1) > 4
        
        c = inf;
        
    elseif x(2) < -7 || x(2) > 4
        
        c = inf;
        
    % check if x fails to satisfy constraints
    elseif x(1)/6 + x(2) - 6.5 > 0      % constraint g_1
        
        c = inf;
        
    elseif 0.5*x(1) + x(2) - 7.5 > 0	% constraint g_2
        
        c = inf;
        
    elseif 5*x(1) + x(2) - 30 > 0   	% constraint g_3
        
        c = inf;
        
    else    % x is in the search space and satisfies constraints
        
        c = 0;
        
    end
end
