% Function 5:  Kursawe function
% Wikipedia:   Test functions for optimization
% Address:     https://en.wikipedia.org/wiki/Test_functions_for_optimization
% Section:     Test functions for multiobjective optimization

function problem = Wiki_prob_5()
    
    % set multiobjective function and constraints (objective functions found below)
    f_{1} = @(x) f(1,x);
    f_{2} = @(x) f(2,x);
    F     = @(x) [f(1,x);f(2,x)];
    Ft    = @(x) [transpose(f(1,x)),transpose(f(2,x))];
    C     = @(x) 0;
    
    % prepare the problem
    problem.prob_name    = 'Wiki-5-Kursawe';
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = [-5,5;-5,5;-5,5];
    problem.dim_domain   = 3;
    problem.num_obj      = 2;
    problem.max_evals    = problem.dim_domain*(problem.num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(m,x)

    if m == 1   % objective function f_1
        
        g = 0;
        for i = 1 : 2
            g = g + (-10*exp(-0.2*sqrt(x(i)^2 + x(i+1)^2)));
        end
        f_x = g + infBar(x);                                     
        
    else        % objective function f_2
        
        g = 0;
        for i = 1 : 3
            g = g + (abs(x(i))^0.8 + 5*sin(x(i)^3));
        end
        f_x = g + infBar(x);
        
    end
end


% infinite barrier function
function c = infBar(x)

    % check if x is outside the search space
    if     x(1) < -5 || x(1) > 5
        
        c = inf;
        
    elseif x(2) < -5 || x(2) > 5
        
        c = inf;
        
    elseif x(3) < -5 || x(3) > 5
        
        c = inf;
        
    else    % x is in the search space
        
        c = 0;
        
    end
end
