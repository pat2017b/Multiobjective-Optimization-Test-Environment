function prob = selectWikiProb(prob_num)

    switch prob_num
        
        case 1;     prob = Wiki_prob_1();
        case 2;     prob = Wiki_prob_2();
        case 3;     prob = Wiki_prob_3();
        case 4;     prob = Wiki_prob_4();
        case 5;     prob = Wiki_prob_5();
        case 6;     prob = Wiki_prob_6();
        case 7;     prob = Wiki_prob_7();
        case 8;     prob = Wiki_prob_8();
        case 9;     prob = Wiki_prob_9();
        case 10;    prob = Wiki_prob_10();
        case 11;    prob = Wiki_prob_11();
        case 12;    prob = Wiki_prob_12();
        case 13;    prob = Wiki_prob_13();
        case 14;    prob = Wiki_prob_14();
        case 15;    prob = Wiki_prob_15();
        case 16;    prob = Wiki_prob_16();
        case 17;    prob = Wiki_prob_17();
        case 18;    prob = Wiki_prob_18();
        case 19;    prob = Wiki_prob_19();
            
    end
    
    prob.set_name = "Wikipedia Test Set";
    
end
