% Function 12: Zitzler-Deb-Thiele's function N.4
% Wikipedia:   Test functions for optimization
% Address:     https://en.wikipedia.org/wiki/Test_functions_for_optimization
% Section:     Test functions for multiobjective optimization

function problem = Wiki_prob_12()
    
    % set multiobjective function and constraints (objective functions found below)
    f_{1} = @(x) f(1,x);
    f_{2} = @(x) f(2,x);
    F     = @(x) [f(1,x);f(2,x)];
    Ft    = @(x) [transpose(f(1,x)),transpose(f(2,x))];
    C     = @(x) 0;
    
    % prepare the problem
    problem.prob_name    = 'Wiki-12-Z&D&T-N.4';
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = [0,1;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5];
    problem.dim_domain   = 10;
    problem.num_obj      = 2;
    problem.max_evals    = problem.dim_domain*(problem.num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(m,x)

    if m == 1   % objective function f_1
        
        f_x = x(1) + infBar(x);                                     
        
    else        % objective function f_2
        
        k = 0;
        for i = 2 : 10
            k = k + x(i)^2 - 10*cos(4*pi*x(i));
        end
        g = 91 + k;
        h   = 1 - sqrt(x(1)/g);
        f_x = g*h + infBar(x);
        
    end
end


% infinite barrier function
function c = infBar(x)

    % check if x is outside the search space
    if x(1) < 0 || x(1) > 1
        c = inf;
        return;
    end
    for i = 2 : 10
        if x(i) < -5 || x(i) > 5
            c = inf;
            return;
        end
    end
    
    % else x is in the search space
    c = 0;
    
end
