% Function 14: Osyczka and Kundu function
% Wikipedia:   Test functions for optimization
% Address:     https://en.wikipedia.org/wiki/Test_functions_for_optimization
% Section:     Test functions for multiobjective optimization

function problem = Wiki_prob_14()
    
    % set multiobjective function and constraints (objective functions found below)
    f_{1} = @(x) f(1,x);
    f_{2} = @(x) f(2,x);
    F     = @(x) [f(1,x);f(2,x)];
    Ft    = @(x) [transpose(f(1,x)),transpose(f(2,x))];
    C1    = @(x) [max(0,2 - x(1) - x(2)),max(0,x(1) + x(2) - 6)];
    C2    = @(x) [max(0,x(2) - x(1) - 2),max(0,x(1) - 3*x(2) - 2)];
    C3    = @(x) [max(0,(x(3)-3)^2 + x(4) - 4),max(0,4 - (x(5)-3)^2 - x(6))];
    C     = @(x) [C1(x),C2(x),C3(x)];
    
    % prepare the problem
    problem.prob_name    = 'Wiki-14-O&K';
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = [0,10;0,10;1,5;0,6;1,5;0,10];
    problem.dim_domain   = 6;
    problem.num_obj      = 2;
    problem.max_evals    = problem.dim_domain*(problem.num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(m,x)

    if m == 1   % objective function f_1
        
        f_x = -25*(x(1)-2)^2-(x(2)-2)^2-(x(3)-1)^2-(x(4)-4)^2-(x(5)-1)^2 + infBar(x);                                     
        
    else        % objective function f_2
        
        k = 0;
        for i = 1 : 6
            k = k + x(i)^2;
        end
        f_x = k + infBar(x);
        
    end
end


% infinite barrier function
function c = infBar(x)

    % check if x is outside the search space
    if     x(1) < 0 || x(1) > 10
        
        c = inf;
        
    elseif x(2) < 0 || x(2) > 10
        
        c = inf;
        
    elseif x(3) < 1 || x(3) > 5
        
        c = inf;
        
    elseif x(4) < 0 || x(4) > 6
        
        c = inf;
        
    elseif x(5) < 1 || x(5) > 5
        
        c = inf;
        
    elseif x(6) < 0 || x(6) > 10
        
        c = inf;
        
    % check if x fails to satisfy constraints
    elseif x(1) + x(2) - 2 < 0          % constraint g_1
        
        c = inf;
        
    elseif 6 - x(1) - x(2) < 0          % constraint g_2
        
        c = inf;
        
    elseif 2 - x(2) + x(1) < 0          % constraint g_3
        
        c = inf;
        
    elseif 2 - x(1) + 3*x(2) < 0        % constraint g_4
        
        c = inf;
        
    elseif 4 - (x(3)-3)^2 - x(4) < 0    % constraint g_5
        
        c = inf;
        
    elseif (x(5)-3)^2 + x(6) - 4 < 0	% constraint g_6
        
        c = inf;
        
    else    % x is in the search space and satisfies constraints
        
        c = 0;
        
    end
end
