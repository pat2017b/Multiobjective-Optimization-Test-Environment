% Function 3:  Fonseca-Fleming function (with n = 3)
% Wikipedia:   Test functions for optimization
% Address:     https://en.wikipedia.org/wiki/Test_functions_for_optimization
% Section:     Test functions for multiobjective optimization

function problem = Wiki_prob_3()
    
    % set multiobjective function and constraints (objective functions found below)
    f_{1} = @(x) f(1,x);
    f_{2} = @(x) f(2,x);
    F     = @(x) [f(1,x);f(2,x)];
    Ft    = @(x) [transpose(f(1,x)),transpose(f(2,x))];
    C     = @(x) 0;
    
    % prepare the problem
    problem.prob_name    = 'Wiki-3-F&F-n3';
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = [-4,4;-4,4;-4,4];
    problem.dim_domain   = 3;
    problem.num_obj      = 2;
    problem.max_evals    = problem.dim_domain*(problem.num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(m,x)

    n = 3;  % n hard-coded to 3

    if m == 1   % objective function f_1
        
        g = 0;
        for i = 1 : n
            g = g + (-(x(i) - 1/sqrt(3))^2);
        end
        f_x = 1 - exp(g) + infBar(x);                                     
        
    else        % objective function f_2
        
        g = 0;
        for i = 1 : n
            g = g + (-(x(i) + 1/sqrt(3))^2);
        end
        f_x = 1 - exp(g) + infBar(x);
        
    end
end


% infinite barrier function
function c = infBar(x)

    n = 3;  % n hard-coded to 3

    % check if x is outside the search space
    for i = 1 : n
        if x(i) < -4 || x(i) > 4
            c = inf;
            return;
        end
    end
    
    % else x is in the search space
    c = 0;
    
end
