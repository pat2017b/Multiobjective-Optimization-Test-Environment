% Functional: Test Problem DTLZ7
% Article:    Scalable Multi-Objective Optimization Test Problems
% Authors:    Deb, Thiele, Laumanns, and Zitzler

function problem = selectDTLZ7Prob(dim_domain,num_obj)

    % the search space is always [0,1]^dim_domain
    search_space = [zeros(dim_domain,1),ones(dim_domain,1)];
    
    % generate functions
    for i = 1 : num_obj
        
        f_{i} = @(x) f(i,x,dim_domain,num_obj,search_space);
        
    end    
    
    % construct the multiobjective vector function
    F = @(x) [];
    
    for i = 1 : num_obj
        
        F = @(x) [F(x);f_{i}(x)];
        
    end
    
    % construct the transpose of the function (for MOPSO and NSGA-II)
    Ft = @(x) [];
    
    for i = 1 : num_obj
        
        Ft = @(x) [Ft(x),transpose(f_{i}(x))];
        
    end
    
    % construct the constraint equations to calculate error (for NSGA-II)
    n  = dim_domain;
    m  = num_obj;
    C_ = cell(1,3);
    for j = 1 : num_obj-1
        
        C_{j} = @(x) max(0,1 - fc(n,m,m,x) - 4*fc(n,m,j,x));
        
    end
    
    % combine the constraints into a vector valued function
    C = @(x) [];
    for i = 1 : num_obj-1
        
        C = @(x) [C(x),C_{i}(x)];
        
    end
    
    C_M = @(x) max(0,-2*fc(n,m,m,x) - min(getK(n,m,x)));
    C   = @(x) [C(x),C_M(x)];
    
    % prepare the problem
    problem.prob_name    = "DTlZ-7 (n=" +  dim_domain + ",m=" + num_obj + ")";
    problem.f_          = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = search_space;
    problem.dim_domain   = dim_domain;
    problem.num_obj      = num_obj;
    problem.max_evals    = dim_domain*(num_obj^2)*100;
    
end


% objective functions with infinite barriers
function f_x = f(i,x,dim_domain,num_obj,search_space)
    
    % shorten values
    n = dim_domain;
    M = num_obj;

    l = floor((i-1)*n/M);
    
    if l < 1 || l > n
        
        l = 1;
        
    end
    
    u = floor(i*n/M);
    
    if u < 1 || u > n
        
        u = 0;
        
    end
    
    %
    k = 0;
    
    for j = l : u
        
        k = k + x(j);
        
    end
    
    f_x = (1/floor(n/M))*k + modInfBar(i,x,n,M,search_space);
    
end


% infinite barrier function
function c = modInfBar(i,x,n,m,ss)

    % check if x is outside the search space
    if infBar(x,ss) > 0
        
        c = inf;
        return;
        
    end
    
    % check if x satisfies the constraints
    if fc(n,m,m,x) + 4*fc(n,m,i,x) - 1 < 0
        c = inf;
        return;
    end

    K = getK(n,m,x);

    if 2*fc(n,m,m,x) + min(K) < 0
        c = inf;
        return;
    end        

    % else x is in the search space and satisfies the constraints
    c = 0;
    
end


% helper function to find K for objective functions and constraints
function K = getK(n,m,x)

    K = zeros(1,(m-1)*n-min(n,(m-1)));
    for i = 1 : m-1
        for j = 1 : m-1
            if i==j
                continue;
            end
            K(i) = fc(n,m,i,x) + fc(n,m,j,x) - 1;
        end
    end
end


% objective functions without infinite barriers (for constraints)
function fc_x = fc(n,m,i,x)

    l = floor((i-1)*n/m);
    if l < 1 || l > n
        l = 1;
    end
    u = floor(i*n/m);
    if u < 1 || u > n
        u = 0;
    end
    k = 0;
    for j = l : u
        k = k + x(j);
    end
    fc_x = (1/floor(n/m))*k;
    
end


% indicator function used to build an infinite barrier outside of the 
% search space
function c = infBar(x,search_space)

    % check if x is outside the search space
    for i = 1 : size(search_space,1)
        
        if x(i) < search_space(i,1)    ||    x(i) > search_space(i,2)
            
            c = inf;
            return;
            
        end
    end
    
    % else if x is inside the search space
    c = 0;
    
end
