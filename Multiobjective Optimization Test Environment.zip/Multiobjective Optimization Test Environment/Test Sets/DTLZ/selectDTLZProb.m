function problem = selectDTLZProb(DTLZ_num,prob_num)

    % override for directly testing specific cases of the functionals
%     override = 1;
%     if override
%         
%         % test DTLZ
%         dim_domain = 2;
%         num_obj    = 3;
%         problem = selectDTLZ7Prob(dim_domain,num_obj);    % change for DTLZ 1 - 7
%         problem.set_name = "DTLZ-7 Test Set";
%         return;
%         
%     end

    % set test set name
    problem.set_name = "DTLZ";

    % NOTE: DTLZ problems 1 to 5 require dim_domain + 1 >= num_obj
    % and problems 6 and 7 require dim_domain >= num_obj
    
    if DTLZ_num < 6     % for DTLZ 1-5
        
        % find the section of the problem in the following array:
        % prob_num: 1   2 3 4   5 6 7 8   9 10 11 12 13   ...
        % dim:      2 | 2 3 3 | 3 4 4 4 | 4  5  5  5  5 | ...
        % obj:      2 | 3 2 3 | 4 2 3 4 | 5  2  3  4  5 | ...
        %________________________________________________________
        % section:  1 |   2   |    3    |       4       | ...
        % sum:      1 |   4   |    8    |      13       | ...
        % decomp:   1 |  1+3  |  1+3+4  |    1+3+4+5    | ...
        % pattern:  ((n+1)(n+2)/2) - 3 for n>1

        % search for the appropriate section
        section = 1;
        while prob_num - (((section+1)*(section+2)/2) - 3) - 1 > 0

            section = section + 1;

        end

        % construct the segment of the array at the given section
        section_dims = [section  ,(section+1)*ones(1,section)];
        section_objs = [section+1,2:section+1];

        % select the problem in that section
        % subtract problem numbers from previous sections
        prob_num_in_section = prob_num - (((section)*(section+1)/2) - 3) - 1;	

        dim_domain = section_dims(prob_num_in_section);
        num_obj    = section_objs(prob_num_in_section);
        
    else                % for DTLZ 6-7
        
        % find the section of the problem in the following array:
        % prob_num: 1   2 3   4 5 6   7 8 9 10  ...
        % dim:      2 | 3 3 | 4 4 4 | 5 5 5 5 | ...
        % obj:      2 | 2 3 | 2 3 4 | 2 3 4 5 | ...
        %________________________________________________________
        % section:  1 |  2  |   3   |    4    | ...
        % sum:      1 |  3  |   6   |    10   | ...
        % decomp:   1 | 1+2 | 1+2+3 | 1+2+3+4 | ...
        % pattern:  n*(n+1)/2

        % search for the appropriate section
        section = 1;
        while prob_num - section*(section+1)/2 > 0

            section = section + 1;

        end

        % construct the segment of the array at the given section
        section_dims = (section+1)*ones(1,section);
        section_objs = 2:section+1;

        % select the problem in that section
        % subtract problem numbers from previous sections
        prob_num_in_section = prob_num - (section-1)*(section)/2;
        
        dim_domain = section_dims(prob_num_in_section);
        num_obj    = section_objs(prob_num_in_section);
    
    end

    % select the problem from the appropriate test set
    switch DTLZ_num
        
        case 1;     problem = selectDTLZ1Prob(dim_domain,num_obj);
        case 2;     problem = selectDTLZ2Prob(dim_domain,num_obj);
        case 3;     problem = selectDTLZ3Prob(dim_domain,num_obj);
        case 4;     problem = selectDTLZ4Prob(dim_domain,num_obj);
        case 5;     problem = selectDTLZ5Prob(dim_domain,num_obj);
        case 6;     problem = selectDTLZ6Prob(dim_domain,num_obj);
        case 7;     problem = selectDTLZ7Prob(dim_domain,num_obj);

    end
end
