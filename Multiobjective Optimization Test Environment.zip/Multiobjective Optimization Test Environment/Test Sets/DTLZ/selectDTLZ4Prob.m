% Functional: Test Problem DTLZ4
% Article:    Scalable Multi-Objective Optimization Test Problems
% Authors:    Deb, Thiele, Laumanns, and Zitzler

function problem = selectDTLZ4Prob(dim_domain,num_obj)

    % the search space is always [0,1]^dim_domain
    search_space = [zeros(dim_domain,1),ones(dim_domain,1)];
    
    % generate functions
    for i = 1 : num_obj
        
        f_{i} = @(x) f(i,x,dim_domain,num_obj,search_space);
        
    end    
    
    % construct the multiobjective vector function
    F = @(x) [];
    
    for i = 1 : num_obj
        
        F = @(x) [F(x);f_{i}(x)];
        
    end
    
    % construct the transpose of the function (for MOPSO and NSGA-II)
    Ft = @(x) [];
    
    for i = 1 : num_obj
        
        Ft = @(x) [Ft(x),transpose(f_{i}(x))];
        
    end
    
    % construct the constraint equations to calculate error (for NSGA-II)
    C = @(x) 0;	% no constraints in this problem set
    
    % prepare the problem
    problem.prob_name    = "DTlZ-4 (n=" +  dim_domain + ",m=" + num_obj + ")";
    problem.f_          = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = search_space;
    problem.dim_domain   = dim_domain;
    problem.num_obj      = num_obj;
    problem.max_evals    = dim_domain*(num_obj^2)*100;
    
end


function f_x = f(i,x,dim_domain,num_obj,search_space)
    
    % shorten values and get the value of k for g(x_M)
    n = dim_domain;
    M = num_obj;
    k = n - M + 1;
    
    % set a different meta-variable mapping: x_i -> (x_i)^100
    x = x.^100;

    % find g(x_M)
    g = sum((x(1:k)-0.5)).^2; 
    
    % then evaluate f_(x)
    if i == 1
        
        % objective function f_1
        f_x = (1+g)*prod(cos(x(1:M-1)*pi/2)) + infBar(x,search_space);                              
        
    else
        
        % objective function f_2 to f_m
        f_x = (1+g)*prod(cos(x(1:M-i)*pi/2))*sin(x(M-i+1)*(pi/2)) + infBar(x,search_space);   
        
    end
end


% indicator function used to build an infinite barrier outside of the 
% search space
function c = infBar(x,search_space)

    % check if x is outside the search space
    for i = 1 : size(search_space,1)
        
        if x(i) < search_space(i,1)    ||    x(i) > search_space(i,2)
            
            c = inf;
            return;
            
        end
    end
    
    % else if x is inside the search space
    c = 0;
    
end
