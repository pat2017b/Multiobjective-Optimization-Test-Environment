% Function Group:  Quadratics (Positive Semi-Definite)

function problem = selectQuadPSDProb(prob_num,dim_sz,obj_sz,ss_bnd)

    % use the problem number as a seed to create a determinitic problem set
    pre_seed = rng;     % hold the current seed while the problem is set
    rng(prob_num);      % set the rng to fix this problem number
    
    % randomly set problem parameters based on input
    dim_domain = randi([dim_sz(1),dim_sz(2)]);
    num_obj    = randi([obj_sz(1),obj_sz(2)]);
    
    % set the search space based on dim_domain    
    search_space = [];
    
    for i = 1 : dim_domain
        
        search_space = [search_space;ss_bnd];
        
    end
    
    % generate functions
    for i = 1 : num_obj
        
        A = 2*(rand(dim_domain)-0.5);
        A = A'*A;   % positive semi-definite
        
        B = 2*(rand(dim_domain,1)-0.5);
        
        C = 2*(rand - 0.5);
        
        f_{i} = @(x) (1/2)*x'*A*x + B'*x + C + infBar(x,search_space);
        
    end
    
    % return the rng to its original state
    rng(pre_seed);
    
    % construct the multiobjective vector function
    F = @(x) [];
    
    for i = 1 : num_obj
        
        F = @(x) [F(x);f_{i}(x)];
        
    end
    
    % construct the transpose of the function (for MOPSO and NSGA-II)
    Ft = @(x) [];
    
    for i = 1 : num_obj
        
        Ft = @(x) [Ft(x),f_{i}(transpose(x))];
        
    end
    
    % construct the constraint equations to calculate error (for NSGA-II)
    C = @(x) 0;	% no constraints in this problem set
    
    % prepare the problem
    problem.set_name     = "Quadratics PSD Test Set";
    problem.prob_name    = "QPSD-" + prob_num + "-n" + dim_domain + "m" + num_obj;
    problem.f_           = f_;
    problem.F            = F;
    problem.Ft           = Ft;
    problem.C            = C;
    problem.search_space = search_space;
    problem.dim_domain   = dim_domain;
    problem.num_obj      = num_obj;
    problem.max_evals    = dim_domain*(num_obj^2)*100;
    
end


% indicator function used to build an infinite barrier outside of the 
% search space
function c = infBar(x,search_space)

    % check if x is outside the search space
    for i = 1 : size(search_space,1)
        
        if x(i) < search_space(i,1)    ||     x(i) > search_space(i,2)
            
            c = inf;
            return;
            
        end
    end
    
    % else if x is inside the search space
    c = 0;
    
end
