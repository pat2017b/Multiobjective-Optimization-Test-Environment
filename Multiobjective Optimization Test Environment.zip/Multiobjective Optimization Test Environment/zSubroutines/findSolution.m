function [data_set,sol_set] = findSolution(alg_names,problem,echo,crash_test)

    % start timing (tic and toc already used in testProblem)
    clock_start = clock;	
    
    % get number of algorithms
    num_algs = size(alg_names,1);
    
    % pre-allocate memory to return variables
    data_set    = cell(num_algs,1);
    sol_set     = cell(2,1);
    
    % define helper variables
    U_app_set_X = [];   % Union of the domain of the approximation sets
    U_app_set_F = [];   % Union of the range  of the approximation sets
        
    % collect data from each algorithm on the problem
    for alg = num_algs : -1 : 1	% reverse order to put Matlab figures in order

        % run this algorithm on the problem
        data_set{alg,1} = solveProblem(alg_names{alg},problem,echo,crash_test);

        % add this algorithm's solution to the pool of solutions
        U_app_set_X = [U_app_set_X,data_set{alg,1}.POpt_X];
        U_app_set_F = [U_app_set_F,data_set{alg,1}.POpt_F];

    end
        
    % filter the union to find the solution sets
    [sol_set{1,1},sol_set{2,1}] = filterParetoPoints(U_app_set_X,U_app_set_F);
    
    % finish timing (tic and toc already used in testProblem)
    clock_end = clock;	
    [days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);
    
    if echo
        
        % display time summary message
        fprintf("Testing of solution to problem " + problem.prob_name)
        fprintf(" completed after %.0fd %.0fh %.0fm %.0fs.\n",days,hrs,mins,secs)
    
    end
end
