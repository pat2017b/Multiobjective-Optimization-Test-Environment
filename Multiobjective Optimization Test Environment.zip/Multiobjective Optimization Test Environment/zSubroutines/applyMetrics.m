function [rel_mtcs,summary] = applyMetrics(data,sol,alg_names,metric_names,echo)
    
    % start timing (tic and toc already used in testProblem)
    clock_start = clock;
    
    % get the number of algorithms, problems, and metrics
    [num_algs,num_probs] = size(data);
    num_mtcs             = size(metric_names,1);
    
    % begin constructing a cell array for the text of results summary
    summary    = {};    % hold chunks of the summary in separate cells
    summary{1} = summarizeIntro(num_probs);  % local function
    
    %%%%%%%%%%%%%%%%%%%%
    % FAILURES
    %%%%%%%%%%%%%%%%%%%%
    % pre-allocate memory
    crashed = zeros(num_algs,num_probs);
    hasNaNs = zeros(num_algs,num_probs);
    
    % collect failure data
    for prob = 1 : num_probs

        for alg = 1 : num_algs
            
            % measure this algorithm's failures on this problem
            crashed(alg,prob) = data{alg,prob}.crashed;
            hasNaNs(alg,prob) = data{alg,prob}.hasNaN_X    ||    data{alg,prob}.hasNaN_F;
            
        end
    end
    
    % add summary text for failures (local function)
    summary{2} = summarizeFails(alg_names,crashed,hasNaNs,num_probs);
        
    %%%%%%%%%%%%%%%%%%%%
    % REMOVE FAILURES
    %%%%%%%%%%%%%%%%%%%%
    % remove failed tests from the data set
    list_fails = sum(crashed,1) | sum(hasNaNs,1);
    filt_data  = data(:,~list_fails);
    filt_sol   = sol(:,~list_fails);
    
    % recalculate number of problems
    num_probs = size(filt_data,2);

    % add summary text for filtered failures (local function)
    summary{3} = summarizeFilt(size(sol,2),num_probs);
    
    %%%%%%%%%%%%%%%%%%%%
    % TIMES
    %%%%%%%%%%%%%%%%%%%%
    % pre-allocate memory to the return variable rel_mtcs
    rel_mtcs = zeros(num_algs,num_probs,num_mtcs);
       
    % determine the times
    rel_mtcs(:,:,1) = applyMetric('Time',filt_data,filt_sol);
    
    % add summary text for times (local function)
    summary{4} = summarizeSection('Time',alg_names,rel_mtcs(:,:,1));
    
    %%%%%%%%%%%%%%%%%%%%
    % CHOSEN METRICS
    %%%%%%%%%%%%%%%%%%%%
    for mtc = 1 : num_mtcs
        
        if echo
            
            fprintf("Applying metric " + metric_names{mtc,1} + ".\n");
            
        end
        
        switch metric_names{mtc,1}

            case 'Hypervolume'
                
                % determine the hypervolumes
                rel_mtcs(:,:,mtc+1) = applyMetric('Hypervolume',filt_data,filt_sol);    % mtc+1 because time is mtc = 1
    
                % add summary text for hypervolumes (local function)
                summary{5} = summarizeSection('HV',alg_names,rel_mtcs(:,:,mtc+1));
                
            case 'Contribution'
                
                % determine the contributions
                rel_mtcs(:,:,mtc+1) = applyMetric('Contribution',filt_data,filt_sol);   
    
                % add summary text for contributions (local function)
                summary{6} = summarizeSection('Ctrb',alg_names,rel_mtcs(:,:,mtc+1));
                        
            case 'Epsilon Indicator'
                
                % determine the epsilon indicators
                rel_mtcs(:,:,mtc+1) = applyMetric('Epsilon Indicator',filt_data,filt_sol);   
                
                % add summary text for epsilon indicators (local function)
                summary{7} = summarizeSection('Eps Ind',alg_names,rel_mtcs(:,:,mtc+1));
                
        end
    end
    
    % finish timing (tic and toc already used in testProblem)
    clock_end = clock;	
    [days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);
   
    % add summary text of the time taken (local function)
    summary{8} = summarizeConc(days,hrs,mins,secs);

    if echo
        
        % display time summary message
        fprintf("Testing of metrics on " + num_probs + " problem(s) completed ")
        fprintf("after %.0fd:%.0fh:%.0fm:%.0fs.\n\n",days,hrs,mins,secs)
    
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOCAL TEXT SUMMARY FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% summary{1}
function lines = summarizeIntro(num_probs)

    lines = strings();      % empty array of strings
    
    % write introduction to the analysis
    lines(1) = "---------------------------------------------------------------------------------------------------------------------------";
    lines(2) = "                                                          ANALYSIS";
    lines(3) = "---------------------------------------------------------------------------------------------------------------------------";
    lines(4) = "Date:               " + datestr(datetime('now'));
    lines(5) = "Number of problems: " + num_probs;
    
end


% summary{2}
function lines = summarizeFails(alg_names,crashed,hasNaNs,num_probs)

    lines = strings();      % empty array of strings
    
    % write failure analysis
    lines(1) = "FAILURE ANALYSIS";
    
    % write column headers
    side = 25;  % padding after the string
    str1 = [pad('Algorithms:',side),pad('Crashed        +',side),pad('Caches have NaN    =',side)];
    str2 = [pad('Total Failures',side),pad('Error Rate (fails/total)',side)];
    lines(2) = [str1,str2];
    
    % get each algorithm's number tests that either crashed or had NaN values
    sum_crashed = sum(crashed,2);
    sum_NaNs    = sum(hasNaNs,2);
    
    % write each algorithm's failure statistics under the column headers
    for alg = 1 : size(alg_names,1)

        str_name  = pad(alg_names{alg},side);
        str_crash = pad(num2str(sum(crashed(alg,:))),side);
        str_NaN   = pad(num2str(sum(hasNaNs(alg,:))),side);
        str_fail  = pad(num2str(sum_crashed(alg)+sum_NaNs(alg)),side);
        str_rate  = pad(num2str((sum_crashed(alg)+sum_NaNs(alg))/num_probs),side);
        lines(alg+2) = [str_name,str_crash,str_NaN,str_fail,str_rate];

    end
end


% summary{3}
function lines = summarizeFilt(num_tests,num_tests_filt)

    lines = strings();      % empty array of strings
    
    % write total tests, failures, and number of remaining tests 
    lines(1)  = num_tests + " TEST(S) COMPLETED.";
    lines(2)  = (num_tests - num_tests_filt) + " TEST(S) FAILED AND WERE REMOVED FROM FURTHER ANALYSIS.";
    lines(3)  = num_tests_filt + " TEST(S) REMAINING FOR ANALYSIS.";
        
end


% summaries{4+} of times and chosen metrics
function lines = summarizeSection(section,alg_names,rel_mtc)

    lines    = strings(); 	% empty array of strings
    seg_lgth = 25;          % length of string segment when padding after a string
    
    switch section
        
        case 'Time';        lines(1) = "TIME ANALYSIS";
        case 'HV';          lines(1) = "HYPERVOLUME ANALYSIS";
        case 'Ctrb';        lines(1) = "CONTRIBUTION ANALYSIS";
        case 'Eps Ind';     lines(1) = "EPSILON INDICATOR ANALYSIS";
            
    end
    
    % write column headers using the section name
    col1 = pad("Algorithms:",seg_lgth);
    col2 = pad("Cumul Rel " + section,seg_lgth);
    col3 = pad("Avg Rel " + section,seg_lgth);
    col4 = pad("Std Dev Rel " + section,seg_lgth);
    lines(2) = col1 + col2 + col3 + col4;   
    
    % make the table under the column headers
    table = makeTable(alg_names,rel_mtc,seg_lgth);
    
    % add the lines from the table
    lines = [lines,table];
    
end


% summary{end}
function lines = summarizeConc(days,hrs,mins,secs)

    lines = strings();      % empty array of strings
    
    % write conclusion to the analysis
    lines(1) = "Completion Time: " + days + "d:" + hrs + "h:" + mins + "m:" + secs + "s.";
    lines(2) = "---------------------------------------------------------------------------------------------------------------------------";
    lines(3) = "                                               ANALYSIS COMPLETED";
    lines(4) = "---------------------------------------------------------------------------------------------------------------------------";
    
end
 

% summary table of metric statistics under column headers
function table = makeTable(alg_names,rel_mtc,seg_lgth)

    table = strings();      % empty array of strings

    % write each algorithm's metric statistics under the column headers
    for alg = 1 : size(alg_names,1)

        str_name = pad(alg_names{alg},seg_lgth);
        str_rel  = pad(num2str(sum(rel_mtc(alg,:))),seg_lgth);
        str_avg  = pad(num2str(mean(rel_mtc(alg,:))),seg_lgth);
        str_std  = pad(num2str(std(rel_mtc(alg,:))),seg_lgth);
        table(alg) = [str_name,str_rel,str_avg,str_std];

    end  
end
