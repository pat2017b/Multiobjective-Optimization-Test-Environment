 function data = solveProblem(alg_name,problem,echo,crash_test)
    
    % run the algorithm
    data = runAlgorithm(alg_name,problem,crash_test);

    if echo
        
        % display summary message
        fprintf("Test " + data.prob_name + " completed after " + pad(num2str(data.time),9))
        fprintf("seconds by algorithm " + pad(alg_name + ".",20))

        % output crash and NaN info on the same line as the summary
        if     data.crashed

            fprintf("It crashed.")

        elseif data.hasNaN_X    ||    data.hasNaN_F

            fprintf("The cache has NaN values.")

        end    

        fprintf("\n")
    
    end
end