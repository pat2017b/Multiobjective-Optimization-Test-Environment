function [data_set,sol_set] = solveTestSet(alg_names,test_params,echo,crash_test)
    
    % start timing (tic and toc already used in testProblem)
    clock_start = clock;
    
    % get number of algorithms and problems
    num_algs  = size(alg_names,1);
    num_probs = test_params.num_probs;
    
    % pre-allocate memory to return variables
    data_set = cell(num_algs,num_probs);
    sol_set  = cell(2,num_probs);
    
    % collect data from each algorithm on each problem
    for prob = 1 : num_probs
        
        % set the problem number for this problem
        test_params.prob_num = prob;
        
        % get the problem
        problem = selectProblem(test_params);
    
        % define helper variables
        U_app_set_X = [];   % Union of the domain of the approximation sets
        U_app_set_F = [];   % Union of the range  of the approximation sets
    
        % collect data from each algorithm on this problem
        for alg = 1 : num_algs

            % run this algorithm on this problem
            data_set{alg,prob} = solveProblem(alg_names{alg,1},problem,echo,crash_test);
            
            % add this algorithm's solution to the pool of solutions for this problem
            U_app_set_X = [U_app_set_X,data_set{alg,prob}.POpt_X];
            U_app_set_F = [U_app_set_F,data_set{alg,prob}.POpt_F];

        end

        % filter the union to find the solution sets
        [sol_set{1,prob},sol_set{2,prob}] = filterParetoPoints(U_app_set_X,U_app_set_F);

    end
	
    % finish timing (tic and toc already used in testProblem)
    clock_end = clock;
    [days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);
    
    if echo

        % display time summary message
        fprintf("Testing on " + num_probs + " problems of ")
        fprintf("test set " + test_params.test_set + " completed ")
        fprintf("after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs)
    
    end
end
