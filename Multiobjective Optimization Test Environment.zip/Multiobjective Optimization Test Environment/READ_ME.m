%% Short Guide for Navigating the Multiobjective Test Environment

%% Table of Contents:
% How to solve multiobjective optimization problems (Tutorial)
% How to compile a data set or test an algorithm
% How to apply metrics to a compiled data set
% How to merge data sets to apply metrics
% Overview of the Multiobjective Optimization Test Environment
% Acknowledgements



%% How to solve multiobjective optimization problems (Tutorial)
% This tutorial assumes a fresh copy of the software with no modifications.
%
%% Example 1: This is a preset example. Just hit Run |>.
% Instructions:
% 1. Open the script file 'ControlPanel_1_SolveProblem.m'.
% 2. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: When the program has completed, a figure with four plots should
% be visible as the upper-most figure. This is the solution plot. That is,
% this is the solution made up of all the combined solutions of the Random
% Search, Grid Search, MOPSO, NSGA-II, and MNM-MeshMap algorithms run on
% this problem. The test problem is the first problem of the Wikipedia 
% problem set. The top two plots of the solution plot show the domain
% (left) and objective space (right) of the final solution. The bottom two
% plots are a poorly labelled illustration of each algorithm's solution
% layed overtop of one another.
%      The next five figures show the individual results of the algorithms
% that participated. For each figure, the left side shows a visualization
% of the objective functions where possible and the right side shows the
% results of the algorithm on the problem. The top two right-most plots
% show the space searched and their corresponding objective space. The red
% points show the Pareto optimal points of the set, the grey points show
% the non-optimal (and finite) points of the set, and the green points show
% the infinite points of the set (for example when a searched point
% fails the constraints). The bottom two right-most figures show the Pareto
% optimal points alone.
%      In the Command Window, the progress of the individual tests are
% printed. This is followed by a notification that all algorithms have
% completed their tests and the solutions have been determined. And finally
% after visualizing, saving, and printing, the problem is solved.
%      In the '_Saved Results' folder of the Multiobjective Optimization
% Test Environment, a folder named 'Solution 1' should have appeared 
% containing the details of the experiment.
%
%
%% Example 2: Change a few parameters.
% Instructions:
% 1. Open the script file 'ControlPanel_1_SolveProblem.m'.
% 2. Near the top of the script, where it reads to choose a from the list 
%    of algorithms, replace this line:
%
%    alg_names = {'Random Search';'Grid Search';'MOPSO';'NSGA-II';'MNM-MeshMap'};
%
%    by this line:
%
%    alg_names = {'MOPSO';'NSGA-II';'MNM-MeshMap'};
%
% 3. In the next section of the script, where it reads to choose from the
%    list of test sets, replace these lines:
%
%    test_params.test_set = 'Wikipedia';
%    test_params.prob_num = 1;
%
%    with these lines:
%
%    test_params.test_set = 'DTLZ';
%    test_params.prob_num = 4;
%
% 4. Just below the code in step 3, uncomment the line
%
%    % test_params.DTLZ_num = 2;
%
%    by removing the %. This sets an extra parameter required by the DTLZ
%    problem set.
% 5. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: In this example, we changed the alg_names, 
% test_params.test_set, and test_params.prob_num parameters and we added a
% new parameter specific to the DTLZ test set. Notice that the progress of
% the test was printed in the Command Window and that a folder named 
% 'Solution 2' should have appeared in the _Saved Results folder.
%
%
%% Example 3: Change a few more parameters.
% Instructions:
% 1. Open the script file 'ControlPanel_1_SolveProblem.m'.
% 2. Change the name of the participating algorithms as in Example 2. Set 
%    alg_names to:
%
%    alg_names = {'MNM-MeshMap'};
%
% 3. Change the test set and problem number as in Example 2 to:
%
%    test_params.test_set = 'Quadratics PSD';
%    test_params.prob_num = 2020;
%
% 4. Add a comment to hide the DTLZ variable to remove it:
%
%    % test_params.DTLZ_num = 2;
%
% 5. Below the DTLZ extra parameter and in the section of extra parameters 
%    for the Quadratic Positive Semi-Definite test set, remove the comments
%    from the three tri-objective parameters:
%
%    % test_params.dim_rge = [1,3];        % [min_dim, max_dim]
%    % test_params.obj_rge = [3,3];        % [min_num_obj, max_num_obj]
%    % test_params.ss_bnd  = [-5,5];       % axis boundaries for each dimension (will make a hypercube)
%
% 6. A little below step 5, override the number of allowed function
%    evalutions by setting the max_evals_override value to ?????:
%
%    max_evals_override = 1000;   % or set to 0 to use problem's default number of max_evals
%
% 7. Below step 6, turn off the save and echo features to avoid saving the
%    experiment and printing out to the Command Window by setting each 
%    corresponding variable to zero:
%
%    save_ = 0;                % 0 = don't save; 1 = do save
%
%    echo = 0;                 % 0 = don't print; 1 = do print
%
% 8. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: In this example, we used the following variables:
% 
% alg_names
% test_params.test_set
% test_params.prob_num
% test_params.dim_rge
% test_params.obj_rge
% test_params.ss_bnd
% max_evals_override
% visual_
% save_
% echo
% crash_test 
%
% Note that the solution window does not appear because the solution is the
% same at the solution of the algorithm. Further note that nothing appeared
% in the Command Window and nothing was saved to the _Saved Results folder.
%
%
%% Example 4: Make your own problem.
% Instructions:
% 1. Open the script file 'ControlPanel_1_SolveProblem.m'.
% 2. Set the following parameters:
%
%    alg_names            = {'Grid Search'};
%    test_params.test_set = 'User Defined';
%    max_evals_override   = 0;
%    visual_              = 1;
%    save_                = 0;
%    echo                 = 1;
%    crash_test           = 1;
% 
% 3. In the Multiobjective Optimization Test Environment, go to the folder
%    Test Sets -> UserDefined and open the function file
%    'userDefinedProb.m'.
%
% 4. In the file 'userDefinedProb.m' scroll down through the cases and at
%    the following code as the last case:
%        
%         case 5      % paraboloid, cubic, and sinusoidal
%             
%             % set parameters
%             prob_name    = "Three Common Functions";
%             search_space = [-5,5;-5,5];
%             dim_domain   = 2;
%             num_obj      = 3;
%             max_evals    = 1000;
%             
%             % write corresponding functions
%             f_{1} = @(x) sum(x.^2) + infBar(x,search_space);
%             f_{2} = @(x) sum(x.^3) + infBar(x,search_space);
%             f_{3} = @(x) sin(.5*x(1)) + cos(.5*x(2)) + infBar(x,search_space);
%
% 5. Finally, set the problem number to match the case number:
%
%    test_params.prob_num = 5;
%


%% How to compile a data set or test an algorithm
% This example assumes a fresh copy of the software with no modifications.
% Instructions:
% 1. Open the script file 'ControlPanel_2_SolveProblem.m'.
% 2. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: The parameters are similar to the parameters in ControlPanel_1.
% Most notably, the test_params.prob_num parameter that determines the
% problem number is replaced with the test_params.num_prob parameter that
% determines the total number of problems to use in the set. Given
% num_probs = n, the compiled data will include all problems from 1 to n.
% Also, the crash_test variable is set to 0 when compiling data to catch
% errors and move on. When debugging a new algorithm, choose crash_test =
% 1. Finally, a folder named 'Data Set 1' should appear in the '_Saved
% Results' folder containing all the compiled data of the experiment.



%% How to apply metrics to a compiled data set
% This example assumes a fresh copy of the software with no modifications 
% and the compiled data from 'How to compile a data set or test an 
% algorithm' above. There should be a 'Data Set 1' folder in the '_Saved 
% Results' folder.
% Instructions:
% 1. Open the script file 'ControlPanel_3_ApplyMetrics.m'.
% 2. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: After the script has completed running, a figure should appear 
% with the accuracy profiles of the Hypervolume, Contribution, and Epsilon
% Indicator metrics. A summary of the results should also be printed in the
% Command Window. Moreover in the 'Data Set 1' folder in '_Saved Results',
% there should appear the saved figure of the accuracy profiles, the
% details of the metrics, the relative metrics values, a summary of the
% analysis of the  metrics (as printed out in the Command Window), and a
% comma-separated values (CSV) file with a summary of the test problems.



%% How to merge data sets to apply metrics
% This example assumes a fresh copy of the software with no modifications. 
% This example also assumes that Example 1 of 'How to solve multiobjective 
% optimization problems (Tutorial)' above has been used to make the
% folder 'Solution 1' and that 'How to compile a data set or test an 
% algorithm' above has been used to compile the 'Data Set 1' folder, both 
% in the '_Saved Results' folder.
% Instructions:
% 1. Open the script file 'ControlPanel_4_MergeData.m'.
% 2. Hit the 'Run' button in the Matlab environment.
%
% COMMENTS: After the script has completed running, the 'Merge 1' folder 
% should appear in '_Saved Results'. The 'ControlPanel_3_ApplyMetrics.m'
% file can then be used to analyze the results of the data in the folder
% 'Merge 1'.



%% Overview of the Multiobjective Optimization Test Environment
% The main folder of the Multiobjective Optimization Test Environment
% contains some folders and ControlPanel scripts. The scripts begin with 
% some variables to set, as can be experienced in the examples above. 
% When the program is run, the paths to relevant folders are added. Next, 
% the algorithms are tested on the problems. This is managed by the 
% function files in the folder 'zSubroutines'. The rest of the code is to 
% time the code, visuazlize in figures, save to file, and print to the 
% command window, with supporting files found in the 'Toolbox' folder.
%      The folders in the test Environment are:
%
% _Saved Results
% Algorithms
% Metrics
% Test Sets
% Toolbox
% zSubroutines
%
% These are described folder by folder below. 
%
% _Saved Results:
% The control panels can save the results of tests. The '_Saved Results' 
% folder is the location where the tests are saved. This is also the folder
% in which control panels 3 and 4 look for the data variables to be 
% analyzed or merged.
%
% Algorithms
% The Algorithms folder contains the folders of the individual algorithms 
% and a runAlgorithm.m file. All of an algorithm's code is kept in its own
% folder. The runAlgorithm.m file connects all the algorithms. First, all
% the paths to the individual algorithm folders are included. Then, the 
% parameters of each algorithm are set, the chosen algorithm is run on the 
% problem, and the output data is prepared.
%
% Metrics
% The Metrics folder contains the folders of the individual metrics and an 
% applyMetric.m file. The architecture is similar to the Algorithms
% folder described above. The applyMetric.m file first connects all the 
% paths to the metric folders, then gets the time statistics of each 
% algorithm, prepares to call the chosen metric function, and finally
% determines the relative metric values.
%
% Test Sets
% The Test Sets folder contains the folders of the individual algorithms 
% and a selectProblem.m file. The architecture is also like the Algorithms
% folder above. The selectProblem.m file first includes the paths to the
% test set folders, prepares the details of the chosen problem, and then
% calls the test set's select_____Prob.m (e.g. selectWikiProb.m for the
% Wikipedia problem set). This file within the test set's folder is where
% the 'problem' structure is prepared. The User Defined test set allows the
% user to create a problem with a case number that can be called from the
% control panels.
%
% Toolbox
% The Toolbox folder contains code for various uses. The control panel 
% scripts make the most use of the Toolbox code visuazlize in figures, save
% to file, and print to the command window.
%
% zSubroutines
% The zSubroutines contain code used by the control panels. They have been
% placed in this folder to be hidden from view. Simply put, the control 
% panels call a subroutine function, that may call other subroutine 
% function, and finally calls the algorithms, metrics, and test sets.



%% Acknowledgements
% This code was part of Patrick Nadeau's master's thesis titled 
% Multiobjective Nelder-Mead Using a Mesh-Map of Weighted Sums. Thank you
% to my supervisor for the guidance given to me throughout my thesis, and
% thank you to everyone who inspired me.
