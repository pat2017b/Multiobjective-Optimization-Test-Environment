clear all; clc;

%% Running analysis on the Epsilon Indicator metric time scenarios.

% the goal here is to measure the time required to test the epsilon indicator between
% two large sets to determine optimal testing parameters
for dim = 2 : 6     % dimensions used in testing
    
    for i = 1 : 4
        
        approx_set_size = 10^i;       % approximation set size
    
        for j = i : 4
            
            sol_set_size = 10^j;   % solution set size
            
            % start timing
            tic;

            % create demonstration sets with some points likely to have negative
            % coordinates (to test the translation code in epsilonIndicator)
            F = 2*rand(dim,approx_set_size)-1;
            S = 2*rand(dim,sol_set_size)-1;

            str1 = pad("Solution set size: " + num2str(sol_set_size),26);
            str2 = pad("Approx set size:   " + num2str(approx_set_size),25);
            str3 = pad("Epsilon Indicator: " + num2str(epsilonIndicator(F,S)),27);
            [~] = toc;      % '[~] =' to suppress timer print-out
            test_time = toc;
            fprintf(str1 + str2 + " Dimension of test: " + dim + "  " + str3+ " after " + toc + " seconds\n")

        end
        
        fprintf("\n")
        
    end
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("Conclusion:")
disp("The Epsilon Indicator begins to be computationally heavy when the solution set")
disp("reaches 10000 points and the approximation set reaches 10000 points.")
