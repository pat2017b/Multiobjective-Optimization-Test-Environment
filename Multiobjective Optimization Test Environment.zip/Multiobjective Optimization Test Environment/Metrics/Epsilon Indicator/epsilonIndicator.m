function eps_ind = epsilonIndicator(approx_set,sol_set)

    % deal with empty approximation set first
    if isempty(approx_set)
        
        eps_ind = 10^9;     % arbitrary large number
        return;
        
    end

    % first, translate the set to the positive sector
    % get the utopia point of the sets
    utopia_pt  = min([approx_set,sol_set],[],2);
    
    % move the sets so that the utopia point is at (1,1,...,1)
    sol_set    = sol_set    + (ones(size(utopia_pt)) - utopia_pt);
    approx_set = approx_set + (ones(size(utopia_pt)) - utopia_pt);
        
    % epsilon indicator = max{a in A}(min{s in S}(max{1<=i<=n}(a_i/s_i)))
    % first initialize the search array
    M = zeros(size(sol_set,2),size(approx_set,2));
    
    % second, find the maximum ratios a_i/s_i between all pairs of vectors
    for s = 1 : size(sol_set,2)
        
        for a = 1 : size(approx_set,2)
            
            M(s,a) = max(max(approx_set(:,a)./sol_set(:,s)));
            
        end
        
    end
    
    % third, minimize the ratio to find the nearest distance for the solution to be dominated
    % then take the biggest of those minimums to ensure every point crosses the domination line
    eps_ind = max(min(M,[],2));
    
    % finally, since the solution set always weakly dominates an
    % approximation set, eps_ind >= 1 implying 0 < 1/eps_ind < 1
    % this is the indicator that is returned
    eps_ind = 1/eps_ind;

end
