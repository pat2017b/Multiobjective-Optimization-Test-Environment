function eps_ind = epsilonIndicatorMC(approx_set,sol_set,max_size)

    % check the size of the approximation set
    if size(approx_set,2) > max_size
        
        % choose a sample subset from the approximation set
        approx_subset = datasample(approx_set,max_size,2);
        
        % run the epsilon indicator on the subset
        eps_ind = epsilonIndicator(approx_subset,sol_set);
        
    else
        
        % the approximation size is relatively small; compute the value directly
        eps_ind = epsilonIndicator(approx_set,sol_set);
    
    end
end

