clear all; clc; % close all;

%% Create a test problem

% test 1
% create a solution set: y = (x-1)^2 for 0<=x<=1
size = 10000;
X    = 1 : 1/(size-1) : 2;
sol_set = [X;(X-2).^2];

% add an outlying point
sol_set = [[1.000001;10],sol_set];

% create an approximation set
size = 1000;
X    = 1.9 : 1/(10*size-1) : 2;
approx_set = [X;(X-(2.2)).^2];

% now add some far off points
approx_set = [[1.01;100],[1.8;3],[1.86;2],approx_set];


% % test 2
% % create a solution set: y = (x-1)^2 for 0<=x<=1
% size = 10000;
% X    = 1 : 1/(size-1) : 2;
% sol_set = [X;(X-2).^2 + 1];
% 
% % create an approximation set
% size = 1000;
% X    = 1.9 : 1/(10*size-1) : 2;
% approx_set = [X;(X-(2.2)).^2 + 1];
% 
% % now add some far off points
% approx_set = [[1.7;6],[1.8;4],[1.86;3],approx_set];


% % test 3
% % create a solution set: y = (x-1)^2 for 0<=x<=1
% size = 10000;
% X    = 1 : 1/(size-1) : 2;
% sol_set = [X;(X-2).^2 + 1000];
% 
% % create an approximation set
% size = 1000;
% X    = 1.9 : 1/(10*size-1) : 2;
% approx_set = [X;(X-(2.2)).^2 + 1000];
% 
% % now add some far off points
% approx_set = [[1.7;1010],[1.8;1007],[1.86;1003],approx_set];


%% calculate the exact epsilon indicator value
tic;
true_eps_ind = epsilonIndicator(approx_set,sol_set);
fprintf("Epsilon Indicator value: " + true_eps_ind + " after " + toc + " seconds.\n")


%% calculate the Monte-Carlo epsilon indicator value
tic;
eps_ind = epsilonIndicatorMC(approx_set,sol_set);
fprintf("An approximate value of " + eps_ind + " is obtained after " + toc + " seconds.\n")


%% calculate the worst approximation after some trials
num_trials = 100;
worst_approx = inf;
for i = 1 : num_trials
    
    eps_ind = epsilonIndicatorMC(approx_set,sol_set);
    if eps_ind < worst_approx
        
        worst_approx = eps_ind;
        
    end
end
fprintf("The worst approximation is: " + worst_approx + " after " + num_trials + " trials\n");

% epsilon indicator using sampling of approximation set
function eps_ind = epsilonIndicatorMC(approx_set,sol_set)

    % maximum size for which the exact epsilon will be computed exactly
    max_size = 500;

    if size(approx_set,2) > max_size    % sol_set size is bounded below by approx_set
        
        % choose a sample subset from the approximation set
        approx_subset = datasample(approx_set,max_size,2);
        
        % run the epsilon indicator on the sets
        eps_ind = epsilonIndicator(approx_subset,sol_set);
        
    else
        
        eps_ind = epsilonIndicator(approx_set,sol_set);
    
    end
end
