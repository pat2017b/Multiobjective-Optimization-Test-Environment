clear all; clc;

%% Running unit analysis on the Epsilon Indicator metric accuracy.
disp("Test 1 tests a few simple cases.")

% test 1a   
A = [2;2];
S = [1;1];

disp("Test 1a")
fprintf("approximation set = [2;2] and solution set = [1;1]\n")
%
%          .(2,2)
%   (1,1).
%
disp("The epsilon indicator is 1/2")
fprintf("The obtained value is " + epsilonIndicator(A,S) + "\n\n")

% test 1b 
A = [1,3;3,2];
S = [1;1];

disp("Test 1b")
fprintf("approximation set = [1,3;3,2] and solution set = [1;1]\n")
%
%    (1,3).       
%               .(3,2) 
%    (1,1).  
%
disp("The epsilon indicator is 1/3")
fprintf("The obtained value is " + epsilonIndicator(A,S) + "\n\n")

% test 1c
A = [3,4;7,2];
S = [1,3;2,1];

disp("Test 1c")
fprintf("approximation set = [3,4;7,2] and solution set = [1,3;2,1]\n")
%
%               .(3,4)
%    (1,3).       
%                         .(7,2) 
%    (1,1).  .(2,1)
%
disp("The epsilon indicator is 1/3.5")
fprintf("The obtained value is " + epsilonIndicator(A,S) + "\n\n")

% test 1c
A = [3,5;10,2];
S = [1,1,3;1,2,1];

disp("Test 1d")
fprintf("approximation set = [3,5;10,2] and solution set = [1,3;2,1]\n")
%
%               .(3,5)
%               
%    (1,3).       
%                                     .(10,2) 
%    (1,1).  .(2,1)
%
disp("The epsilon indicator is 1/5")
fprintf("The obtained value is " + epsilonIndicator(A,S) + "\n\n")


fprintf("\nThe second unit test tests the accuracy of the indicator by simulating a situation\n")
fprintf("where the indicator converges to 1. The test sets are randomly chosen from the\n")
fprintf("Ix = 1 hyperplane. (Note that the end points from I are always included.)\n")
fprintf("The tests are then repeated in higher dimensions.\n\n")

for dim = 2 : 6     % dimensions used in testing
    
    fprintf("For dimension " + dim + ", the epsilon indicator is bounded by 1 and " + dim + "\n")
    
    % increase the number of points used in the sets
    for k = 1 : 3
        
        % prepare a Pareto optimal planes
        num_pts = 10^k;
        
        % randomly create two hyperplanes with equation I*x = 1 and including I  
        A = [eye(dim),makeParetoHyperplane(dim,num_pts)];
        S = [eye(dim),makeParetoHyperplane(dim,num_pts)];

        str = pad(num2str(num_pts),4);
        fprintf("The obtained epsilon indicator for " + str + " is " + epsilonIndicator(A,S) + "\n")
    
    end
    
    fprintf("\n")
    
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("TESTS CONCLUDED")


function P = makeParetoHyperplane(dim,num_points)

    % make random points in the plane
    P      = zeros(dim,num_points);
    P(1,:) = rand(1,num_points);
    
    for i = 2 : dim - 1
        
        P(i,:) = rand(1,num_points).*(1-sum(P(1:i-1,:),1));
        
    end
    
    P(dim,:) = 1-sum(P(1:dim-1,:),1);
    
    % resort the points for a more even distribution
    for i = 1 : size(P,2)
        
        P(:,i) = P(transpose(randperm(size(P,1))),i);
        
    end
end
