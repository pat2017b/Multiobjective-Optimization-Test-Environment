clear all; clc;

%% Running analysis on the Hypervolume metric time scenarios.
% the goal here is to maximize the sample_size bound by a time constraint
% to determine optimal testing parameters
time_constraint = 5; % seconds
test_set_size = 100000;

for dim = 2 : 6     % dimensions used in testing
    
    % starting sample size
    sample_size = 1;
    
    % stopping variable
    test_time = 0;

    while test_time < time_constraint
    
        % start timing
        tic;

        % increment sample size to find upper bound within time constraint
        sample_size = sample_size*10;

        F  = rand(test_set_size,dim);
        AU = ones(1,dim);
        U  = zeros(1,dim);
        N  = sample_size;

        str1 = pad("Sample size: " + num2str(sample_size),23);
        str2 = pad("Test set size: " + num2str(test_set_size),25);
        str3 = pad("Hypervolume: " + num2str(hypervolume(F,AU,U,N)),23);
        [~] = toc;      % '[~] =' to suppress timer print-out
        test_time = toc;
        fprintf(str1 + str2 + " Dimension of test: " + dim + "    " + str3+ " after " + toc + " seconds\n")

    end
    
    fprintf("Maximum sample size calculated in close to " + time_constraint + " second(s): " + sample_size + "\n\n")
    
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("Conclusion:")
disp("A sample size of 100,000 should not take more than a few seconds to run on an ")
disp("approximation set as large as 100,000 vectors.")
