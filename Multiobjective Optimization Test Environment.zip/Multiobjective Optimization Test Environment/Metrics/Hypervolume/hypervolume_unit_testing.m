clear all; clc;

% choose the number of samples in the hypervolume approximation
sample_size = 100000;

% choose the number of tests to verify the accuracy of the measurement
num_tests = 1000000;


%% Running unit analysis on the Hypervolume metric accuracy.
% perform the tests on several dimensions
for dim = 2 : 6     
    
    F  = .5*ones(1,dim);       
    AU = ones(1,dim);
    U  = zeros(1,dim);
    N  = sample_size;

    % theoretical hypervolume = 1/(2^n)
    theory_hv = 1/(2^dim);
    fprintf("The theoretical hypervolume in " + dim + " dimensions is " + theory_hv + "\n")
    
    % an example of the simulated hypervolume
    fprintf("This simulated hypervolume in " + dim + " dimensions is " + hypervolume(F,AU,U,N) + "\n")
    
    % find the largest difference between the approximated and theoretical
    % hypervolumes
    hv_diff_max = 0;

    for i = num_tests

        hv = hypervolume(F,AU,U,N);
        hv_diff = abs(theory_hv - hv);

        if hv_diff > hv_diff_max

            hv_diff_max = hv_diff;

        end
    end

    fprintf("The maximum difference found after " + num_tests + " tests is " + (hv_diff_max/theory_hv)*100 + "%%\n\n")
    
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("Conclusion:")
disp("A sample size of 100,000 should give an accuracy of approximately 10^2.")
