function rel_mtcs = applyMetric(mtc_name,data,sol)

    % include paths to metric folders
    % first determine operating system for folder naming
    if     ispc

        slash = '\';

    elseif ismac

        slash = '/';

    end
    
    % include paths to metric folders
    addpath([pwd,slash,'Metrics',slash,'Hypervolume']);
    addpath([pwd,slash,'Metrics',slash,'Contribution']);
    addpath([pwd,slash,'Metrics',slash,'Epsilon Indicator']);

    % get the number of algorithms, problems, and metrics
    [num_algs,num_probs] = size(data);

    % pre-allocate memory to metric value and relative value arrays
    metric_vals = zeros(size(data));
    rel_mtcs    = zeros(size(data));
    
    % measure the times in the data
    for prob = 1 : num_probs

        for alg = 1 : num_algs

            % get the algorithms' times on this problem
            metric_vals(alg,prob) = data{alg,prob}.time;   

        end

        % find the minimum time on this problem
        min_time = min(metric_vals(:,prob),[],1);

        % measure the relative time = alg_time / min_time
        for alg = 1 : num_algs

            % calculate this algorithm's relative time on this problem
            rel_mtcs(alg,prob) = metric_vals(alg,prob)/min_time;

        end
    end
    
    switch mtc_name
        
        case 'Hypervolume'

            % measure the hypervolumes in the data
            for prob = 1 : num_probs

                % prepare variables to approximate the hypervolume
                AU = transpose(max(sol{2,prob},[],2));      % anti-utopian point
                U  = transpose(min(sol{2,prob},[],2));      % utopian point
                N  = 100000;                                % number of simulations
                
                for alg = 1 : num_algs

                    % calculate this algorithm's hypervolume
                    F = transpose(data{alg,prob}.POpt_F);
                    metric_vals(alg,prob) = hypervolume(F,AU,U,N);

                end    

                % check for zero hypervolumes (e.g. single point fronts)
                % if this problem has a zero hypervolume solution
                if metric_vals(:,prob) == zeros(num_algs,1)

                    % give every algorithm a relative hypervolume of 1
                    % (to avoid NaNs in relative metric values (below))
                    metric_vals(:,prob) = ones(num_algs,1);

                end

                % calculate relative hypervolume = alg_hv / max_hv
                max_hv = max(metric_vals(:,prob),[],1);

                for alg = 1 : num_algs

                    rel_mtcs(alg,prob) = metric_vals(alg,prob)/max_hv;

                end                    
            end
            
        case 'Contribution'
            
            % measure the contributions in the data
            for prob = 1 : num_probs

                for alg = 1 : num_algs

                    % calculate this algorithm's contribution on this problem
                    F = data{alg,prob}.POpt_F;
                    metric_vals(alg,prob) = contribution(F,sol{2,prob});

                end
                
                % calculate relative contribution = alg_ctrb / max_ctrb
                max_ctrb = max(metric_vals(:,prob),[],1);

                for alg = 1 : num_algs

                    rel_mtcs(alg,prob) = metric_vals(alg,prob)/max_ctrb;

                end 
            end
            
        case 'Epsilon Indicator'

            % for approximation sets, use a sample of this number if over this number
            max_size = 500;

            % measure the epsilon indicators in the data
            for prob = 1 : num_probs

                for alg = 1 : num_algs

                    % calculate this algorithm's epsilon indicator on this problem
                    F = data{alg,prob}.POpt_F;
                    metric_vals(alg,prob) = epsilonIndicatorMC(F,sol{2,prob},max_size);

                end            

                % calculate relative epsilon indicator = alg_ei / max_ei
                max_ei = max(metric_vals(:,prob),[],1);

                for alg = 1 : num_algs

                    rel_mtcs(alg,prob) = metric_vals(alg,prob)/max_ei;

                end 
            end

    end
end
