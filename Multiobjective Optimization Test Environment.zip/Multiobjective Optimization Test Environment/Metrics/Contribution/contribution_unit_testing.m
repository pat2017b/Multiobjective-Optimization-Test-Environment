clear all; clc;

% choose the number of samples in comparing the contribution
sample_size = 10000;

% choose the number of common samples between the two sets (i.e. the
% contribution)
common_sample = 1000;


%% Running unit analysis on the Contribution metric accuracy.

fprintf("\nBeginning tests with a sample size of " + sample_size + " and common sample size of " + common_sample + "\n")
fprintf("The expected contribution is " + common_sample/sample_size + "\n\n")

for dim = 2 : 6     % dimensions used in testing
    
    % points that will be common to both sets
    C = rand(dim,common_sample);
   
    % simulated set F to be measured against solution set S (sharing C)
    F = [C,rand(dim,sample_size-common_sample)];
    S = [C,rand(dim,sample_size-common_sample)];
    
    fprintf("In " + dim + " dimensions, the contribution obtained is " + contribution(F,S) + "\n")
    
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("TEST CONCLUDED")