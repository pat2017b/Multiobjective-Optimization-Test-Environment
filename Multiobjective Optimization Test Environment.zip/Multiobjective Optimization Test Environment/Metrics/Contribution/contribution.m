function ctrb = contribution(F,sol_set)

    pts_ctrb = 0;

    for i = 1 : size(F,2)
        
        % if F_i is in the solution set...
        if sum(sum(bsxfun(@eq,F(:,i),sol_set),1))
            
            % count it.
            pts_ctrb = pts_ctrb+1;
            
        end
    end

    ctrb = pts_ctrb/size(sol_set,2);

end