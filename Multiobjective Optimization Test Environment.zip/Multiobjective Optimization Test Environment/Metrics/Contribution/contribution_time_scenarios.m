clear all; clc;

% choose the number of common samples between the two sets (i.e. the
% contribution)
common_sample = 100;


%% Running analysis on the Contribution metric time scenarios.

for k = 1 : 4
    
    % sizes of approximation set and solution set used in contribution test
    approx_size = 10^k;
    sol_size    = 10^(k+1);

    fprintf("\nBeginning tests with a sample size of " + sol_size + " and common sample size of " + common_sample + "\n")
    fprintf("The expected contribution is " + common_sample/sol_size + "\n\n")
    
    % time these tests by dimension
    for dim = 2 : 6     % dimensions used in testing

        % points that will be common to both sets
        C = rand(dim,common_sample);

        % simulated set F to be measured against solution set S (sharing C)
        F = [C,rand(dim,approx_size-common_sample)];
        S = [C,rand(dim,sol_size-common_sample)];
        
        tic;
        fprintf("In " + dim + " dimensions, the contribution obtained is " + contribution(F,S))
        fprintf(" in " + toc + " seconds\n")

    end
end

disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
disp("Conclusion:")
disp("An approximation set size of 10,000 vectors compared to a solution set of 100,000")
disp("takes several seconds, while 1,000 with 10,000 is still well below 1 second.")