%% Please see the READ_ME file for details on how to use this Control Panel.
clear all; clc; % close all;
%
% This script runs a set of algorithms on a test set with a given number of
% problems to either test an algorithm or collect data for analysis.
%
% Choose a set of algorithms, a test set and the number of problems, and 
% some test parameters. Choose to save (in '_Saved Results'), produce an 
% echo, or crash-test (allowing the algorithms to crash and stop the 
% program).


%% Choose from the list of available algorithms:
% 'Random Search'
% 'Grid Search'
% 'MOPSO'           % Multi-Objective Particle Swarm Optimization
% 'NSGA-II'         % Non-Dominated Sorting Genetic Algorithm
% 'MNM-MeshMap'     % Multiobjective Nelder-Mead using a Mesh-Map of Weighted Sums
% (See Algorithms -> runAlgorithm.m to set algorithm parameters.)
alg_names = {'Random Search';'Grid Search';'MOPSO';'NSGA-II';'MNM-MeshMap'};


%% Choose from the list of available test sets:
% 'Wikipedia'               % a set of problems found on Wikipedia (prob_num <= 19 for this one)
% 'DTLZ'                    % Deb, Thiele, Laumanns, and Zitzler Scalable Test Set (7 problem types)
% 'Quadratics'              % Quadratic objective functionals
% 'Quadratics PSD'          % Positive Semi-Definite Quadratics
% 'Sine Polynomials'        % Sinusoidal and Polynomial behaviour around 0 
% 'User Defined Problems'   % see Test Sets -> User Defined -> userDefinedProb.m
test_params.test_set = 'Wikipedia';             
test_params.num_probs = 19;

%*********************************
% Set extra DTLZ test parameters:

% DTLZ number (between 1 and 7, or 0 for full set)
% test_params.DTLZ_num = 1;

%*********************************
% Set extra Quadratics, Quadratics PSD, and Sine Polynomials parameters:

% (bi-objective)
% test_params.dim_rge = [1,3];        % [min_dim, max_dim]
% test_params.obj_rge = [2,2];        % [min_num_obj, max_num_obj]
% test_params.ss_bnd  = [-5,5];       % axis boundaries for each dimension (will make a hypercube)

% (tri-objective)
% test_params.dim_rge = [1,3];        % [min_dim, max_dim]
% test_params.obj_rge = [3,3];        % [min_num_obj, max_num_obj]
% test_params.ss_bnd  = [-5,5];       % axis boundaries for each dimension (will make a hypercube)

% (larger variables)
% test_params.dim_rge = [1,10];   	  % [min_dim, max_dim]
% test_params.obj_rge = [2,10];   	  % [min_num_obj, max_num_obj]
% test_params.ss_bnd  = [-5,5];    	  % axis boundaries for each dimension (will make a hypercube)


%% Choose whether to save the results in '_Saved Results' folder.
save_ = 1;       % 0 = don't save; 1 = do save


%% Choose whether to receive command window messages updating the progress.
echo = 1;       % 0 = don't print; 1 = do print


%% Choose whether to allow an algorithm to crash and stop the program.
crash_test = 0;     % 0 = don't stop on a crash; 1 = do stop on a crash





%% Begin running the algorithms on the test set.
% start timing
clock_start = clock;

% include paths to main folders
% first determine operating system for folder naming
if     ispc

    slash = '\';

elseif ismac

    slash = '/';

end

% add paths to the following folders
addpath([pwd,slash,'Algorithms']);
addpath([pwd,slash,'Test Sets']);

% include all paths in the toolbox
addpath(genpath([pwd,slash,'Toolbox']));

% collect the data
[data,sol] = solveTestSet(alg_names,test_params,echo,crash_test);

% finish timing
clock_end = clock;
[days,hrs,mins,secs] = getTimeLapsed(clock_start,clock_end);


%% Save
if save_
    
    % create a new folder in the _Saved Results folder
    save_path = getSavePath(['_Saved Results',slash,'Data Set'],slash);
    mkdir(save_path);
    
    save([save_path,slash,'data.mat'],'data');
    save([save_path,slash,'solutions.mat'],'sol');
    
    % save a summary of the details
    file_name = [save_path,slash,'details.txt'];
    fileID = fopen(file_name,'a');
    fprintf(fileID,"Details of Data Set - " + datestr(datetime('now')) + "\n\n");
    fprintf(fileID,pad("Algorithms: ",25) + strjoin(alg_names,', ') + "\n");
    fprintf(fileID,pad("Problem Set: ",25) + test_params.test_set + "\n");
    fprintf(fileID,pad("Number of Problems: ",25) + test_params.num_probs + "\n");
    
    if isfield(test_params, 'DTLZ_num')
        
        fprintf(fileID,"\nExtra DTLZ Parameters:\n");
        fprintf(fileID,pad("DTZL number: ",25) + test_params.DTLZ_num + "\n");

    end
    
    if isfield(test_params, 'dim_rge')
        
        fprintf(fileID,"\nExtra Quadratics, Quadratics PSD, and Sine Polynomials Parameters:\n");
        fprintf(fileID,pad("Dimension Range: ",25) + "[" + test_params.dim_rge(1) + "," + test_params.dim_rge(2) + "]\n");
        fprintf(fileID,pad("Objective Range: ",25) + "[" + test_params.obj_rge(1) + "," + test_params.obj_rge(2) + "]\n");
        fprintf(fileID,pad("Search Space Bounds: ",25) + "[" + test_params.ss_bnd(1) + "," + test_params.ss_bnd(2) + "]\n\n");
    
    end
    
    fprintf(fileID,"Data Set completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs);
    
    fprintf(fileID,"\n");
    fclose(fileID);
    
end

% print summary message
if echo
    
    fprintf("Data Set completed after %.0fd:%.0fh:%.0fm:%.0fs.\n",days,hrs,mins,secs)
    
end
